### Assessment for Lab 09

#### Total score: _100_ / _100_

Run on March 03, 11:59:28 AM.


#### Necessary Files and Structure

+  _40_ / _40_ : Pass: Check that directory "project" exists.

+ Pass: Change into directory "project".

+ Pass: Check that directory "config" exists.

+ Pass: Check that directory "docs" exists.

+ Pass: Check that directory "drivers" exists.

+ Pass: Check that directory "src" exists.

+ Pass: Check that directory "tests" exists.

+ Pass: Check that directory "web_code/web" exists.

+ Pass: Check that directory "web_graphics" exists.


#### .gitignore configured properly

+ Pass: Check that file/directory "build" does not exist.

+  _20_ / _20_ : Pass: Check that file/directory "build/bin/vis_sim" does not exist.


#### Compile Tests

+ Pass: Change into directory "src".

+  _30_ / _30_ : Pass: Check that make compiles.



+ Pass: Change into directory "..".

+  _10_ / _10_ : Pass: Check that file "build/bin/vis_sim" exists.

#### Total score: _100_ / _100_

