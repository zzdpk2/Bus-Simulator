### Feedback for Lab 06

Run on February 21, 12:55:12 PM.


#### System Files and Directory Structure

+ Pass: Check that directory "labs" exists.

+ Pass: Check that directory "labs/lab06_gdb" exists.

+ Pass: Change into directory "labs/lab06_gdb".


#### Test that code compiles and creates the exectuable

+ Pass: Check that make compiles.



+ Pass: Check that file "date" exists.

+ Pass: Program executes flawlessly.



+ Pass: Check for correct output.

    Complete.



