#include "gtest/gtest.h"

#include <iostream>
#include <math.h>
#include <ctime>

#include "date.h"


class DateTest : public ::testing::Test {
 public:
  void SetUp( ) {
    // code here will execute just before the test ensues
	first_day = Date(2018, 9, 4);
	last_day = Date(2018, 12, 11);
  }
 protected:
  Date first_day;          // first day of classes
  Date last_day;           // last day of classes
};


TEST_F(DateTest, PrintDateTests) {
  Date y2k(1999, 12, 31);              // y2k
  Date ind_day(1776, 7, 4);            // US Independence
  Date best_holiday(2018, 10, 31);     // Halloween

  std::string expected_out_1 = "1999-12-31\n";
  std::string expected_out_2 = "1776-07-04\n";
  std::string expected_out_3 = "2018-10-31\n";

  testing::internal::CaptureStdout();
  y2k.PrintDate(true);
  std::string output1 = testing::internal::GetCapturedStdout();

  testing::internal::CaptureStdout(); // You must do this EVERY TIME, or else it will segfault
  ind_day.PrintDate(true);
  std::string output2 = testing::internal::GetCapturedStdout();

  testing::internal::CaptureStdout();
  best_holiday.PrintDate(true);
  std::string output3 = testing::internal::GetCapturedStdout();

  EXPECT_EQ(output1, expected_out_1);
  EXPECT_EQ(output2, expected_out_2);
  EXPECT_EQ(output3, expected_out_3);
}

TEST_F(DateTest, PrintDateTestsWithoutNewline) {
  Date y2k(1999, 12, 31);              // y2k
  Date ind_day(1776, 7, 4);            // US Independence
  Date best_holiday(2018, 10, 31);     // Halloween

  std::string expected_out_1 = "1999-12-31";
  std::string expected_out_2 = "1776-07-04";
  std::string expected_out_3 = "2018-10-31";

  testing::internal::CaptureStdout();
  y2k.PrintDate(false);
  std::string output1 = testing::internal::GetCapturedStdout();

  testing::internal::CaptureStdout();
  ind_day.PrintDate(false);
  std::string output2 = testing::internal::GetCapturedStdout();

  testing::internal::CaptureStdout();
  best_holiday.PrintDate(false);
  std::string output3 = testing::internal::GetCapturedStdout();

  EXPECT_EQ(output1, expected_out_1);
  EXPECT_EQ(output2, expected_out_2);
  EXPECT_EQ(output3, expected_out_3);
}

/**
  *
  * Note, this is the only provided test case which actually uses our test fixture
  *
  * However, it is illegal to mix TEST() and TEST_F() in the same test case (file).
  *
  */


 // GetDate() test
TEST_F(DateTest, GetDate) {
  EXPECT_EQ(first_day.GetDate(), "2018-09-04") << "first_day.GetDate() is not setup properly";
  EXPECT_EQ(last_day.GetDate(), "2018-12-11") << "last_day.GetDate() is not setup properly";

  Date test_date(0);

  EXPECT_EQ(test_date.GetDate(), "1970-01-01") << "missing a character void constructor incorrect (standard)";

}

// GetUsDate test
TEST_F(DateTest, GetUsDate) {
  EXPECT_EQ(first_day.GetUsDate(), "09-04-2018") << "first_day.GetUsDate() is not setup properly";
  EXPECT_EQ(last_day.GetUsDate(), "12-11-2018") << "last_day.GetUsDate() is not setup properly";
}

// DaysBetweenTests() test
TEST_F(DateTest, DaysBetweenTests) {
  EXPECT_EQ(first_day.GetUsDate(), "09-04-2018") << "First day of class not setup properly";
  EXPECT_EQ(last_day.GetUsDate(), "12-11-2018") << "Last day of class not setup properly";
  EXPECT_EQ(first_day.DaysBetween(last_day), 98) << "Days between is not calculated properly";
  EXPECT_EQ(last_day.DaysBetween(first_day), 98) << "Days between is not calculated properly";
  // Corner case
  Date date_first(2016, 1, 1), date_second(2016, 3, 1);
  EXPECT_EQ(date_first.DaysBetween(date_second), 60) << "Days between is not calculated properly";

  EXPECT_EQ(first_day.DaysBetween(first_day), 0) << "Days between is not calculated properly";
}


// operators tests
// + test
TEST_F(DateTest, PlusOverrideTest) {
  EXPECT_EQ(first_day.GetUsDate(), "09-04-2018") << "Plus operator override failed!";
  Date first_day_new = first_day + 5;
  EXPECT_EQ(first_day_new.GetUsDate(), "09-09-2018") << "Plus operator override failed!";

  first_day_new = first_day_new + (-1);
  EXPECT_EQ(first_day_new.GetUsDate(), "09-08-2018") << "Plus operator override failed!";

  // float case
  first_day_new = first_day + 7.5;
  EXPECT_EQ(first_day_new.GetUsDate(),"09-11-2018") << "Plus operator override failed!";

  first_day_new = first_day + 30;
  EXPECT_EQ(first_day_new.GetUsDate(),"10-04-2018") << "Plus operator override failed!";

}

// - test
TEST_F(DateTest, MinusOverrideTest) {

  Date first_day_new_zero = first_day - 0;
  EXPECT_EQ(first_day_new_zero.GetDate(), "2018-09-04") << "Minus operator override failed!";

  Date first_day_new = first_day - 2;
  EXPECT_EQ(first_day_new.GetDate(), "2018-09-02") << "Minus operator override failed!";

  first_day_new = first_day_new - (-1);
  EXPECT_EQ(first_day_new.GetDate(), "2018-09-03") << "Minus operator override failed!";

  first_day_new = first_day - 31;
  EXPECT_EQ(first_day_new.GetDate(),"2018-08-04") << "Minus operator override failed!";

  first_day_new = first_day - 62;
  EXPECT_EQ(first_day_new.GetDate(),"2018-07-04") << "Minus operator override failed!";

  // float case
  first_day_new = first_day - 5.5;
  EXPECT_EQ(first_day_new.GetDate(),"2018-08-30") << "Minus operator override failed!";

}

// Mutant 3: Test local time
TEST_F(DateTest, LocalScheduleTest) {
  Date local_date;

  std::time_t t = std::time(0);
  std::tm* now = std::localtime(&t);
  Date local_date_push(now->tm_year + 1900, now->tm_mon + 1, now->tm_mday);

  EXPECT_EQ(local_date.GetUsDate(), local_date_push.GetUsDate()) << "Real-time case failed!";
}

// Constructor Tests
TEST_F(DateTest, ConstructorTests) {

  // for epoch: one parameter
  Date epoch_date_zero(0);
  EXPECT_EQ(epoch_date_zero.GetDate(),"1970-01-01") << "Epoch constructor failed!";

  Date epoch_date_positive(100);
  Date epoch_date_negative(-100);
  EXPECT_EQ(epoch_date_positive.GetDate(),"1970-01-01") << "Epoch constructor failed!";
  EXPECT_EQ(epoch_date_negative.GetDate(),"1969-12-31") << "Epoch constructor failed!";

  // Y2K
  Date epoch_date_max_int(2147483647);
  Date epoch_date_min_int(-2147483647);
  EXPECT_EQ(epoch_date_max_int.GetDate(),"2038-01-19") << "Epoch constructor failed!";
  EXPECT_EQ(epoch_date_min_int.GetDate(),"1901-12-13") << "Epoch constructor failed!";

  Date epoch_date_positive_float(100000.5);
  Date epoch_date_negative_float(-100000.5);
  EXPECT_EQ(epoch_date_max_int.GetDate(),"2038-01-19") << "Epoch constructor failed!";
  EXPECT_EQ(epoch_date_min_int.GetDate(),"1901-12-13") << "Epoch constructor failed!";

  // for three parameters
  // year tests
  Date year_zero(0, 1, 1);
  EXPECT_EQ(year_zero.GetDate(),"0-01-01") << "Three constructor failed!";

  Date year_positive_int(11, 1, 1);
  Date year_negative_int(-11, 1, 1);

  EXPECT_EQ(year_positive_int.GetDate(),"11-01-01") << "Three constructor failed!";
  EXPECT_EQ(year_negative_int.GetDate(),"-11-01-01") << "Three constructor failed!";

  Date year_float_positive(10.5, 1, 1);
  Date year_float_negative(-10.5, 1, 1);
  EXPECT_EQ(year_float_positive.GetDate(),"10-01-01") << "Three constructor failed!";
  EXPECT_EQ(year_float_negative.GetDate(),"-10-01-01") << "Three constructor failed!";

  // month tests
  Date month_zero(1970, 0, 1);
  EXPECT_EQ(month_zero.GetDate(),"1970-00-01") << "Three constructor failed!";

  Date month_negative(1970, -11, 1);
  EXPECT_EQ(month_negative.GetDate(),"1970-0-11-01") << "Three constructor failed!";

  Date month_float(1970, 10.5, 1);
  EXPECT_EQ(month_float.GetDate(),"1970-10-01") << "Three constructor failed!";

  // day tests
  Date day_zero(1970, 1, 0);
  EXPECT_EQ(day_zero.GetDate(), "1970-01-00") << "Three constructor failed!";

  Date day_negative(1970, 1, -10);
  EXPECT_EQ(day_negative.GetDate(), "1970-01-0-10")  << "Three constructor failed!";

  Date day_float(1970, 1, 10.5);
  EXPECT_EQ(day_float.GetDate(), "1970-01-10") << "Three constructor failed!";

}


/**
  *
  * NOPE!  Can't test PRIVATE methods
  *
  */
/*
TEST(DateTest, ConvertFrstd::time(0)omDays) {
	Date convert_first_day = ConvertToDays(2458365);
	EXPECT_STREQ(convert_first_day.GetUsDate(), "09-04-2018");
}
*/
