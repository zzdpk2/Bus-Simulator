#include <iostream>
#include <cstdlib>
#include <math.h>
#include "point2.h"

using namespace std;

float Point2::DistanceBetween(Point2 point){

    float dx = 0.0, dy = 0.0;
    dx = (x - point.GetX()) * (x - point.GetX());
    dy = (y - point.GetY()) * (y - point.GetY());
    return sqrt(dx + dy);

}

int Point2::Quadrant(){
    if(x > 0){

		if(y > 0) return 1;
		
		else if(y < 0) return 4;

		else    return 1;
		
	}else if (x < 0) {

		if(y < 0)	return 3;
		
		else if(y > 0)  return 2;
		
		else    return 3;
		
	}else{ 

		if(y < 0)   return 4;
		
		else if(y > 0)  return 2;
		
		else    return 0;
	}
}

void Point2::Print(){
    cout << "[" << x << "," << y << "]" << endl;
}

float Point2::GetX()  {   return x;   }
float Point2::GetY()  {   return y;   } 