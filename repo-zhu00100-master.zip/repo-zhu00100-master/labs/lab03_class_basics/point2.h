class Point2{
    private:
        float x;
        float y;

    public:
        Point2(){
            x = 0;
            y = 0;
        }
        
        Point2(float x_, float y_){
            x = x_;
            y = y_;
        }

        float DistanceBetween(Point2 point);
        int Quadrant();
        void Print();

        float GetX();  
        float GetY(); 

};