/**
 * @file passenger_factory.cc
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#ifndef LABS_LAB07_STYLE_DOXY_SRC_MAINPAGE_H_
#define LABS_LAB07_STYLE_DOXY_SRC_MAINPAGE_H_

/*! \mainpage My Personal Index Page
 *
 * \section intro_sec Introduction
 *
 * This is the introduction.
 * Good one!
 */

#endif  // LABS_LAB07_STYLE_DOXY_SRC_MAINPAGE_H_
