/**
 * @file passenger.h
 *
 * @copyright 2020 Rex Zhu, All rights reserved.
 */

#ifndef SRC_PASSENGER_H_
#define SRC_PASSENGER_H_

/*******************************************************************************
 * Includes
 ******************************************************************************/
#include <iostream>
#include <string>

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
 * @brief The main class for the generation of passengers.
 *
 * Calls to \ref Generate function to get a new instance of a passenger.
 *  This is a static call, not requiring an instance to invoke the method.
 */
class Passenger {
  // : public Reporter {
 public:
  /**
  * @brief construcor for Passenger class.
  *
  * @param[in] destination_stop_id destination id is for destination id(default value -1).
  * @param[in] name "Nobody" is the initial value of name if there is no input.
  *
  * @return no return value
  */
  explicit Passenger(int = -1, std::string = "Nobody");
    /**
  * @brief This is the Update function
  */
  void Update();
  void GetOnBus();
  int GetTotalWait() const;
  bool IsOnBus() const;
  int GetDestination() const;
  void Report() const;

 private:
  /**
  * @brief private members of Passenger
  */
  std::string name_;
  int destination_stop_id_;
  int wait_at_stop_;
  int time_on_bus_;
  int id_;
  // global count, used to set ID for new instances
  static int count_;
};
#endif  // SRC_PASSENGER_H_
