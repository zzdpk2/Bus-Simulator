### Feedback for Lab 09

Run on March 02, 11:33:47 AM.


#### Necessary Files and Structure

+ Pass: Check that directory "project" exists.

+ Pass: Change into directory "project".

+ Pass: Check that directory "config" exists.

+ Pass: Check that directory "docs" exists.

+ Pass: Check that directory "drivers" exists.

+ Pass: Check that directory "src" exists.

+ Pass: Check that directory "tests" exists.

+ Pass: Check that directory "web_code/web" exists.

+ Pass: Check that directory "web_graphics" exists.


#### .gitignore configured properly

+ Pass: Check that file/directory "build" does not exist.

+ Pass: Check that file/directory "build/bin/vis_sim" does not exist.


#### Compile Tests

+ Pass: Change into directory "src".

+ Pass: Check that make compiles.



+ Pass: Change into directory "..".

+ Pass: Check that file "build/bin/vis_sim" exists.

