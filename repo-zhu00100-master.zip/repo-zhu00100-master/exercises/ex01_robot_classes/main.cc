#include <iostream>
#include "robot.h"

using namespace std;

int main() {

  Robot rosy_robot;
  Robot c3po_robot(100, 100);
  Robot hal_robot((float)3.14);
  Robot eva_robot(-100,-100,-3.14/4.0);
  rosy_robot.Display();
  c3po_robot.Display();
  hal_robot.Display();
  eva_robot.Display();

  return 0;

}
