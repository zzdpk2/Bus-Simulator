### Feedback for Lab 02

Run on February 06, 10:42:48 AM.


#### Necessary Files and Structure

+ Pass: Check that directory "labs" exists.

+ Pass: Check that directory "labs/lab02_build_process" exists.

+ Pass: Change into directory "labs/lab02_build_process".


### Essential Files Exist

+ Pass: Check that file "Makefile" exists.

+ Pass: Check that file ".gitignore" exists.


### .gitignore set up properly

+ Pass: Check that no files with extension ".o" exist in directory "."

+ Pass: Check that no files with extension ".out" exist in directory "."


### Test that code compiles and creates executable

+ Pass: Check that make compiles.



+ Pass: Check that file "ducks" exists.

