### Assessment for Lab 10

#### Total score: _100.0_ / _100_

Run on March 03, 15:19:37 PM.


### Necessary Files and Structure

+  _10_ / _10_ : Pass: Check that directory "labs" exists.

+  _10_ / _10_ : Pass: Check that directory "labs/lab10_advanced_git" exists.


### Git Usage

+  _10_ / _10_ : Pass: Run git ls-remote to check for existence of specific branch- Branch devel found

+ Pass: Checkout devel branch.



+ Pass: Run git ls-remote gather all branches in repo

		84d630a4a4ab3a0e775ec632c68e2f871d644063	refs/heads/devel

		13a36111401cf8ed1710a9e3df5e937211d42e80	refs/heads/fix/01-compilation-errors

		caf48d36db72fb2bd31b682c9e1c175c91e19684	refs/heads/fix/02-ggsyntax-enhancement

		7617d10c3cbcab0aca41e05cbe13a2fc36b93941	refs/heads/master



+  _10_ / _10_ : Pass: Checking for the correct number of branches

Sufficient branches found (found=2, required=2):

fix/01-compilation-errors

fix/02-ggsyntax-enhancement


#### Counting commits on devel

+ Pass: Checkout devel branch.



+ Pass: Gather commit history

		[zhu00100] 2020-02-29 (HEAD -> devel, origin/devel) fixed final syntax error and final check 

		[zhu00100] 2020-02-29 fixed final syntax error and final check 

		[zhu00100] 2020-02-29 readme 

		[zhu00100] 2020-02-29 fixed 

		[zhu00100] 2020-02-29 new 

		[zhu00100] 2020-02-29 Merge branch 'master' into devel dsfds 

		[zhu00100] 2020-02-29 new 

		[zhu00100] 2020-02-29 Merge branch 'master' of github.umn.edu:umn-csci-3081-s20/repo-zhu00100 :new 

		[zhu00100] 2020-02-29 new 

		[zhu00100] 2020-02-29 new 

		[zhu00100] 2020-02-29 Merge branch 'devel' new 


		[zhu00100] 2020-02-29 new 

		[zhu00100] 2020-02-29 new 

		[zhu00100] 2020-02-29 Merge branch 'master' of github.umn.edu:umn-csci-3081-s20/repo-zhu00100 new 

		[zhu00100] 2020-02-29 final 


		[zhu00100] 2020-02-29 new 

		[zhu00100] 2020-02-29 new 

		[zhu00100] 2020-02-29 Merge branch 'master' of github.umn.edu:umn-csci-3081-s20/repo-zhu00100 new 

		[zhu00100] 2020-02-29 update lab10 


		[zhu00100] 2020-02-29 new 

		[zhu00100] 2020-02-29 Merge branch 'master' into devel merged 

		[zhu00100] 2020-02-29 final check 


		[zhu00100] 2020-02-29 update lab10 

		[zhu00100] 2020-02-29 Merge branch 'fix/01-compilation-errors' fix01: to master

                     no production code change)



		[zhu00100] 2020-02-28 Merge branch 'devel' of github.umn.edu:umn-csci-3081-s20/repo-zhu00100 into devel 

		[zhu00100] 2020-02-28 Merge branch 'fix/01-compilation-errors' into devel 

		[zhu00100] 2020-02-28 (origin/fix/01-compilation-errors, fix/01-compilation-errors)  fix(files): fix #1 solve bug in bus.cc - Multiple lines of description
- Lists all the important elements that have been changed
- etc.


		[zhu00100] 2020-02-28 Adding files 




		[zhu00100] 2020-02-27 lab10 init 

		[zhu00100] 2020-02-27 Merge branch 'support-code' of github.umn.edu:umn-csci-3081-s20/csci3081-shared-upstream into support-code 

		[zhu00100] 2020-02-27 new 



		[zhu00100] 2020-02-27 new 


		[zhu00100] 2020-02-25 lab10 





		[zhu00100] 2020-02-25 new 

		[zhu00100] 2020-02-25 Merge branch 'master' of github.umn.edu:umn-csci-3081-s20/repo-zhu00100 

		[zhu00100] 2020-02-25 new 



		[zhu00100] 2020-02-25 fixing 

		[zhu00100] 2020-02-25 Merge branch 'support-code' 

		[zhu00100] 2020-02-25 Merge branch 'support-code' of github.umn.edu:umn-csci-3081-s20/csci3081-shared-upstream into support-code 

		[zhu00100] 2020-02-25 delete 

		[zhu00100] 2020-02-25 new 













		[zhu00100] 2020-02-24 Merge branch 'support-code' 

		[zhu00100] 2020-02-24 Merge branch 'support-code' of github.umn.edu:umn-csci-3081-s20/csci3081-shared-upstream into support-code 

		[zhu00100] 2020-02-24 new 

		[zhu00100] 2020-02-24 new 


		[zhu00100] 2020-02-24 new 









































































		[zhu00100] 2020-02-21 new 









		[zhu00100] 2020-02-20 new 


		[zhu00100] 2020-02-20 new 


		[zhu00100] 2020-02-20 new 


		[zhu00100] 2020-02-20 new 


		[zhu00100] 2020-02-20 new 


		[zhu00100] 2020-02-20 new 


		[zhu00100] 2020-02-20 new 


		[zhu00100] 2020-02-20 new 


		[zhu00100] 2020-02-20 new 


		[zhu00100] 2020-02-20 new 




		[zhu00100] 2020-02-20 new 


		[zhu00100] 2020-02-20 new 


		[zhu00100] 2020-02-20 new 


		[zhu00100] 2020-02-20 new 


		[zhu00100] 2020-02-20 new 


		[zhu00100] 2020-02-20 new 


		[zhu00100] 2020-02-20 new 


		[zhu00100] 2020-02-20 new 


		[zhu00100] 2020-02-20 new 


		[zhu00100] 2020-02-20 new 


		[zhu00100] 2020-02-20 new 


		[zhu00100] 2020-02-20 new 
















+  _5_ / _5_ : Pass: Check git commit history
Sufficient commits (found=75,required=4)


### Git Issue Usage

+ Pass: Configuring GHI

+ Pass: Run ghi for total number of open issues in Github repo (Found: 0)

+ Pass: Run ghi for total number of closed issues in Github repo (Found: 5)

[CLOSED issue #6] :  Google Tests Syntax Enhancement  [enhancement]

[CLOSED issue #5] :  Google Tests Syntax Enhancement

[CLOSED issue #3] :  Bug 1:bus.h line 100

[CLOSED issue #2] :  Bug route.cc line 34

[CLOSED issue #1] :  Bug Bus.cc line 100





+  _10.0_ / _10_ : Pass: Run ghi for total number of issues in Github repo (Found: 5, Expected: 2) 

 [OPEN issue #] : 

[CLOSED issue #6] :  Google Tests Syntax Enhancement  [enhancement]

[CLOSED issue #5] :  Google Tests Syntax Enhancement

[CLOSED issue #3] :  Bug 1:bus.h line 100

[CLOSED issue #2] :  Bug route.cc line 34

[CLOSED issue #1] :  Bug Bus.cc line 100

 




### Test that code on  devel compiles

+ Pass: Checkout devel branch.



+  _10_ / _10_ : Pass: Check that directory "project/src" exists.

+ Pass: Change into directory "project/src".

+  _5_ / _5_ : Pass: Check that file "makefile" exists.

+  _30_ / _30_ : Pass: Check that make compiles.



#### Total score: _100.0_ / _100_

