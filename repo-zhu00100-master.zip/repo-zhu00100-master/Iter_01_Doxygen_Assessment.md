### Iteration 1 - Doxygen Partial Assessment (Graded By: Suhail Alnahari)

Run on April 03, 01:05:34 AM.

<hr>

This Partial Assessment indicates a TA has begun grading your Doxygen-generated documentation. However, documentation will be graded using a Canvas rubric and grades will only be posted on Canvas once every student's documentation has been graded. We ask for your patience at this time.

<hr>

+ Pass: Checkout iteration 1 final submission.




#### Necessary Files and Structure

+ Pass: Check that directory "project" exists.

+ Pass: Check that directory "project/src" exists.

+ Pass: Check that directory "project/tests" exists.

+ Pass: Check that directory "project/docs" exists.


#### Doxygen Tests

+ Pass: Change into directory "project/docs".

+ Pass: Check that file "Doxyfile" exists.

+ Pass: Generating documentation by running doxygen

+ Pass: Check that file "html/index.html" exists.

+ Pass: Inspecting Doxygen webpages...



<hr>

This Partial Assessment indicates a TA has begun grading your branches and issues. However, this will be graded using a tallying spreadsheed and grades will only be posted to Canvas once every student's branches and issues have been graded. We ask for your patience at this time.

  Please note: Branches are counted throughout Iteration 1. We are looking for branches you made and left alone during Iteration 1. Issues however are counted for the entirety of the semester. We ran into some glitches automatically grading this, so this is the solution we came up with.

<hr>

+ Pass: Configuring GHI

+  _2_ / _2_ : Pass: This test counts the number of branches made during development of Iteration 1

Sufficient branches found (found=11, required=8):

add-skip-function

doxgen-finished

edit-settings

fix#10-edit-doxygen-for-src

fix#11-edit-doxygen-for-web_code/web

fix-issue#7-Google-Style-on-Bus

fix-issue#9-Add-Buttons

fix-issue#9-Add-pause

fix/01-compilation-errors

fix/02-ggsyntax-enhancement

upload-mainpage.h

+  _2.0_ / _2_ : Pass: Run ghi for total number of issues in Github repo (Found: 21, Expected: 8) 

 [OPEN issue #] : 

[CLOSED issue #24] :  edited ↑

[CLOSED issue #23] :  Branch Conflict

[CLOSED issue #22] :  VSCode Setting JSON Error [invalid]

[CLOSED issue #21] :  Doxgen finished ↑

[CLOSED issue #19] :  Start to write Mainpage.h

[CLOSED issue #18] :  Doxygen finished

[CLOSED issue #17] :  fixing-Editing Doxygen for web_code/web files [enhancement]

[CLOSED issue #16] :  fixing-Editing Doxygen for src files [enhancement]

[CLOSED issue #15] :  Doxygen Enhancement in web_code/web  [enhancement]

[CLOSED issue #14] :  Devel ↑

[CLOSED issue #13] :  Dev Skip Function [enhancement]

[CLOSED issue #12] :  Add Logics to Pause adn Resume

[CLOSED issue #11] :  Add Buttons [enhancement]

[CLOSED issue #10] :  Add Buttons

[CLOSED issue #9] :  Devel ↑

[CLOSED issue #7] :  Google Style Errors on Bus Classes [enhancement]

[CLOSED issue #6] :  Google Tests Syntax Enhancement  [enhancement]

[CLOSED issue #5] :  Google Tests Syntax Enhancement

[CLOSED issue #3] :  Bug 1:bus.h line 100

[CLOSED issue #2] :  Bug route.cc line 34

[CLOSED issue #1] :  Bug Bus.cc line 100

 




#### Counting commits on devel

+ Pass: Checkout devel branch.



+ Pass: Gather commit history

		[zhu00100] 2020-03-24 (HEAD, tag: iteration1-final-devel, tag: iteration1-final) done 

		[zhu00100] 2020-03-24 (origin/edit-settings, edit-settings) done 

		[zhu00100] 2020-03-24 edited 

		[zhu00100] 2020-03-24 ignore vscode config files 

		[zhu00100] 2020-03-24 finshed mainpage.h 

		[zhu00100] 2020-03-24 finshed mainpage.h 

		[zhu00100] 2020-03-22 finshed except for UML 

		[zhu00100] 2020-03-22 add new stuff 

		[zhu00100] 2020-03-22 temp 

		[zhu00100] 2020-03-19 finished 

		[zhu00100] 2020-03-19 Merge branch 'devel' 

		[zhu00100] 2020-03-19 Merge branch 'devel' of github.umn.edu:umn-csci-3081-s20/repo-zhu00100 into devel 

		[zhu00100] 2020-03-19 finished 

		[zhu00100] 2020-03-19 finished 

		[zhu00100] 2020-03-19 finished 

		[zhu00100] 2020-03-19 finished 

		[zhu00100] 2020-03-19 finished 

		[zhu00100] 2020-03-19 finish mainpage.h 

		[zhu00100] 2020-03-19 finish mainpage.h 

		[zhu00100] 2020-03-19 (origin/upload-mainpage.h, upload-mainpage.h) finish mainpage.h 

		[zhu00100] 2020-03-19 editing 

		[zhu00100] 2020-03-19 fixed issue#11 

		[zhu00100] 2020-03-19 fixed issue#11 

		[zhu00100] 2020-03-19 fixed issue#11 

		[zhu00100] 2020-03-19 (origin/doxgen-finished, doxgen-finished) fixed issue#11 

		[zhu00100] 2020-03-19 finished Doxygen 

		[zhu00100] 2020-03-18 (origin/fix#11-edit-doxygen-for-web_code/web, fix#11-edit-doxygen-for-web_code/web) fixed issue#11 

		[zhu00100] 2020-03-18 editing web_code/web doxygen 

		[zhu00100] 2020-03-18 editing web_code/web doxygen 

		[zhu00100] 2020-03-18 (origin/fix#10-edit-doxygen-for-src, fix#10-edit-doxygen-for-src) finished editting for src doxygen 

		[zhu00100] 2020-03-18 adding new files 

		[zhu00100] 2020-03-17 new 

		[zhu00100] 2020-03-17 almost finished doxygen part 

		[zhu00100] 2020-03-17 finshed all .h .cc doxygen 

		[zhu00100] 2020-03-16 finshed all .h doxygen 

		[zhu00100] 2020-03-16 update doxygen in web_code 

		[zhu00100] 2020-03-16 update doxygen in web_code 

		[zhu00100] 2020-03-16 finished visual simulator doxygen 

		[zhu00100] 2020-03-16 finished visual simulator doxygen 

		[zhu00100] 2020-03-16 finished doxygen in src 

		[zhu00100] 2020-03-16 new 

		[zhu00100] 2020-03-15 finished doxygen in src 

		[zhu00100] 2020-03-15 finished random_passenger_generator.h 

		[zhu00100] 2020-03-15 finishedrandom_passenger_generator.h 

		[zhu00100] 2020-03-15 new 

		[zhu00100] 2020-03-15 resume editing Doxygen 

		[zhu00100] 2020-03-15 new 

		[zhu00100] 2020-03-15 editing doxygen 

		[zhu00100] 2020-03-14 working on doxygen file 

		[zhu00100] 2020-03-14 update comment 

		[zhu00100] 2020-03-14 init doxygen 

		[zhu00100] 2020-03-14 init Doxygen file 

		[zhu00100] 2020-03-14 Merge branch 'master' into devel 

		[zhu00100] 2020-03-14 adjust LoadPassenger to bool 

		[zhu00100] 2020-03-13 (origin/add-skip-function, add-skip-function) Add skip function 

		[zhu00100] 2020-03-13 fixed issue #9 

		[zhu00100] 2020-03-13 (origin/fix-issue#9-Add-pause, fix-issue#9-Add-pause) fixed issue #10 

		[zhu00100] 2020-03-13 (origin/fix-issue#9-Add-Buttons, fix-issue#9-Add-Buttons) fix add buttons issues 

		[zhu00100] 2020-03-13 Merge branch 'devel' 

		[zhu00100] 2020-03-13 (origin/fix-issue#7-Google-Style-on-Bus, fix-issue#7-Google-Style-on-Bus) Google style on Bus has been solved 

		[zhu00100] 2020-03-13 found google test mismatch on bus 

		[zhu00100] 2020-03-12 created doxygen 

		[zhu00100] 2020-03-12 finish cpplint check on web_code/web 

		[zhu00100] 2020-03-12 delete identation 

		[zhu00100] 2020-03-12 new 

		[zhu00100] 2020-03-12 new 

		[zhu00100] 2020-03-12 new 

		[zhu00100] 2020-03-12 re-do 

		[zhu00100] 2020-03-12 Merge branch 'devel' of github.umn.edu:umn-csci-3081-s20/repo-zhu00100 into devel 

		[zhu00100] 2020-03-12 new 

		[zhu00100] 2020-03-12 Merge branch 'support-code' of github.umn.edu:umn-csci-3081-s20/csci3081-shared-upstream into support-code 

		[zhu00100] 2020-03-12 new 

		[zhu00100] 2020-03-11 new 

		[zhu00100] 2020-03-11 rebase 

		[zhu00100] 2020-03-10 new 

		[zhu00100] 2020-03-09 new files 

		[zhu00100] 2020-03-09 new files 

		[zhu00100] 2020-03-09 Merge branch 'devel' of github.umn.edu:umn-csci-3081-s20/repo-zhu00100 into devel 

		[zhu00100] 2020-03-08 add new 

		[zhu00100] 2020-03-08 Merge branch 'devel' of github.umn.edu:umn-csci-3081-s20/repo-zhu00100 into devel 

		[zhu00100] 2020-03-07 Creating bus factory class 

		[zhu00100] 2020-03-07 finshed Iteration1 Deliverables3 Step1 

		[zhu00100] 2020-03-07 revised 

		[zhu00100] 2020-03-06 (tag: Iter1D2) done 

		[zhu00100] 2020-03-06 done 

		[zhu00100] 2020-03-06 finished 

		[zhu00100] 2020-03-06 Merge branch 'devel' of github.umn.edu:umn-csci-3081-s20/repo-zhu00100 into devel 

		[zhu00100] 2020-03-06 Merge branch 'devel' merged


		[zhu00100] 2020-03-06 finish 

		[zhu00100] 2020-03-06 finish 

		[zhu00100] 2020-03-06 new 

		[zhu00100] 2020-03-06 Merge branch 'devel' of github.umn.edu:umn-csci-3081-s20/repo-zhu00100 into devel 

		[zhu00100] 2020-03-06 new 

		[zhu00100] 2020-03-06 Merge branch 'devel' of github.umn.edu:umn-csci-3081-s20/repo-zhu00100 into devel 

		[zhu00100] 2020-03-06 new 

		[zhu00100] 2020-03-06 new 

		[zhu00100] 2020-03-06 new 

		[zhu00100] 2020-03-06 new 

		[zhu00100] 2020-03-06 new 


		[zhu00100] 2020-03-06 new 

		[zhu00100] 2020-03-06 new 

		[zhu00100] 2020-03-05 new 

		[zhu00100] 2020-03-05 update new files 

		[zhu00100] 2020-03-05 new 

		[zhu00100] 2020-03-05 new 

		[zhu00100] 2020-03-05 new 

		[zhu00100] 2020-03-05 new 

		[zhu00100] 2020-03-05 new 

		[zhu00100] 2020-03-05 new 

		[zhu00100] 2020-03-06 new 

		[zhu00100] 2020-03-06 new 

		[zhu00100] 2020-03-06 new 

		[zhu00100] 2020-03-05 new 

		[zhu00100] 2020-03-05 new 

		[zhu00100] 2020-03-05 new 

		[zhu00100] 2020-03-05 new 

		[zhu00100] 2020-03-05 new 

		[zhu00100] 2020-03-05 update new files 

		[zhu00100] 2020-03-05 del 

		[zhu00100] 2020-03-05 update 

		[zhu00100] 2020-03-05 update new files 

		[zhu00100] 2020-03-05 update src 


		[zhu00100] 2020-03-05 new 

		[zhu00100] 2020-03-05 new 

		[zhu00100] 2020-03-05 new 

		[zhu00100] 2020-03-05 init 




		[zhu00100] 2020-03-05 init 


		[zhu00100] 2020-03-04 solving conflict 

		[zhu00100] 2020-03-04 synchronize from PC ubuntu 




























		[zhu00100] 2020-02-29 fixed syntax issue 

		[zhu00100] 2020-02-29 Merge branch 'devel' merge from devel 

		[zhu00100] 2020-02-29 Merge branch 'master' of github.umn.edu:umn-csci-3081-s20/repo-zhu00100 

		[zhu00100] 2020-02-29 fixed final syntax error and final check 

		[zhu00100] 2020-02-29 fixed final syntax error and final check 


		[zhu00100] 2020-02-29 readme 

		[zhu00100] 2020-02-29 fixed 


		[zhu00100] 2020-02-29 new 

		[zhu00100] 2020-02-29 Merge branch 'master' into devel dsfds 

		[zhu00100] 2020-02-29 new 

		[zhu00100] 2020-02-29 Merge branch 'master' of github.umn.edu:umn-csci-3081-s20/repo-zhu00100 :new 

		[zhu00100] 2020-02-29 new 

		[zhu00100] 2020-02-29 new 

		[zhu00100] 2020-02-29 Merge branch 'devel' new 


		[zhu00100] 2020-02-29 new 

		[zhu00100] 2020-02-29 new 

		[zhu00100] 2020-02-29 Merge branch 'master' of github.umn.edu:umn-csci-3081-s20/repo-zhu00100 new 

		[zhu00100] 2020-02-29 final 


		[zhu00100] 2020-02-29 new 

		[zhu00100] 2020-02-29 new 

		[zhu00100] 2020-02-29 Merge branch 'master' of github.umn.edu:umn-csci-3081-s20/repo-zhu00100 new 

		[zhu00100] 2020-02-29 update lab10 


		[zhu00100] 2020-02-29 new 

		[zhu00100] 2020-02-29 Merge branch 'master' into devel merged 

		[zhu00100] 2020-02-29 final check 


		[zhu00100] 2020-02-29 update lab10 

		[zhu00100] 2020-02-29 Merge branch 'fix/01-compilation-errors' fix01: to master

                     no production code change)



		[zhu00100] 2020-02-28 Merge branch 'devel' of github.umn.edu:umn-csci-3081-s20/repo-zhu00100 into devel 

		[zhu00100] 2020-02-28 Merge branch 'fix/01-compilation-errors' into devel 

		[zhu00100] 2020-02-28 (origin/fix/01-compilation-errors, fix/01-compilation-errors)  fix(files): fix #1 solve bug in bus.cc - Multiple lines of description
- Lists all the important elements that have been changed
- etc.



		[zhu00100] 2020-02-28 Adding files 




		[zhu00100] 2020-02-27 lab10 init 

		[zhu00100] 2020-02-27 Merge branch 'support-code' of github.umn.edu:umn-csci-3081-s20/csci3081-shared-upstream into support-code 

		[zhu00100] 2020-02-27 new 



		[zhu00100] 2020-02-27 new 


		[zhu00100] 2020-02-25 lab10 





		[zhu00100] 2020-02-25 new 

		[zhu00100] 2020-02-25 Merge branch 'master' of github.umn.edu:umn-csci-3081-s20/repo-zhu00100 

		[zhu00100] 2020-02-25 new 



		[zhu00100] 2020-02-25 fixing 

		[zhu00100] 2020-02-25 Merge branch 'support-code' 

		[zhu00100] 2020-02-25 Merge branch 'support-code' of github.umn.edu:umn-csci-3081-s20/csci3081-shared-upstream into support-code 

		[zhu00100] 2020-02-25 delete 

		[zhu00100] 2020-02-25 new 













		[zhu00100] 2020-02-24 Merge branch 'support-code' 

		[zhu00100] 2020-02-24 Merge branch 'support-code' of github.umn.edu:umn-csci-3081-s20/csci3081-shared-upstream into support-code 

		[zhu00100] 2020-02-24 new 

		[zhu00100] 2020-02-24 new 


		[zhu00100] 2020-02-24 new 




















+  _1_ / _1_ : Pass: Check git commit history
Sufficient commits (found=185,required=15)

