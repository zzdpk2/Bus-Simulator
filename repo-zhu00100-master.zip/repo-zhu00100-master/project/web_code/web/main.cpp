/**
 * @file main.cpp
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
 /**
 *  @file   main.cpp
 *  @brief  main entrance for web
 *  @author Boss
 *  @date   2020-03-17
 ***********************************************/
/*******************************************************************************
  * Includes
******************************************************************************/
#include <iostream>

#include "src/config_manager.h"
#include "web_code/web/visualization_simulator.h"

#include "web_code/web/my_web_server_session_state.h"
#include "web_code/web/my_web_server_command.h"
#include "web_code/web/my_web_server_session.h"
#include "web_code/web/my_web_server.h"

// #define _USE_MATH_DEFINES
// #include <cmath>
// #include <libwebsockets.h>
/**
* @brief This main function
*
* @param[in] argc specify the number of arguments
* @param[in] argv specify the data structure to save arguments
*
* @return a int to show final status of a program
*/
/******** Main Function *******/
int main(int argc, char**argv) {
  // Print prompt
  std::cout << "Usage: ./build/bin/ExampleServer 8081" << std::endl;
  if (argc > 1) {
    // Extract port number
    int port = std::atoi(argv[1]);
    // Init vars and instances
    MyWebServerSessionState state;

    MyWebServer* myWS = new MyWebServer();
    ConfigManager* cm = new ConfigManager();
    cm->ReadConfig("config.txt");
    std::cout << "Using default config file: config.txt" << std::endl;

    VisualizationSimulator* mySim = new VisualizationSimulator(myWS, cm);

    // Declare commands
    state.commands["getRoutes"] = new GetRoutesCommand(myWS);
    state.commands["getBusses"] = new GetBussesCommand(myWS);
    state.commands["start"] = new StartCommand(mySim);
    state.commands["update"] = new UpdateCommand(mySim);
    state.commands["initRoutes"] = new InitRoutesCommand(cm);
    state.commands["pause"] = new PauseCommand(mySim);
    state.commands["listenBus"] = new AddListenerCommand(mySim);
    state.commands["listenStop"] = new AddStopListenerCommand(mySim);

    // Turn on the service and run the service
    WebServerWithState<MyWebServerSession, MyWebServerSessionState>
      server(state, port);
    while (true) {
      server.service();
    }
  }
  return 0;
}
