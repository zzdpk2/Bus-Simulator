/**
 * @file visualization_simulator.cc
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
/*******************************************************************************
  * Includes
******************************************************************************/
#include <string>

#include "web_code/web/visualization_simulator.h"
// #include "src/bus_factory.h"
// #include "src/bus.h"

/*******************************************************************************
 * Member Functions
 ******************************************************************************/
// VisualizationSimulator constructor
VisualizationSimulator::VisualizationSimulator(WebInterface* webI,
  ConfigManager* configM) {
  webInterface_ = webI;
  configManager_ = configM;
}

// VisualizationSimulator deconstructor
VisualizationSimulator::~VisualizationSimulator() {}

// Start function
void VisualizationSimulator::Start(const std::vector<int>& busStartTimings,
  const int& numTimeSteps) {
  // Detect whether the program is running or pausing
  is_prog_running = true;
  busStartTimings_ = busStartTimings;
  numTimeSteps_ = numTimeSteps;
  // Init time steps
  timeSinceLastBus_.resize(busStartTimings_.size());
  for (int i = 0; i < static_cast<int>(timeSinceLastBus_.size()); i++) {
    timeSinceLastBus_[i] = 0;
  }
  // Reset elapsed simluation time
  simulationTimeElapsed_ = 0;
  prototypeRoutes_ = configManager_->GetRoutes();
  for (int i = 0; i < static_cast<int>(prototypeRoutes_.size()); i++) {
    prototypeRoutes_[i]->Report(std::cout);
    prototypeRoutes_[i]->UpdateRouteData();
    webInterface_->UpdateRoute(prototypeRoutes_[i]->GetRouteData());
  }
}

// Update VisualizationSimulator
void VisualizationSimulator::Update() {
  if (is_prog_running == false) return;
  if (is_prog_running == true && is_bus_pause == true) return;
  simulationTimeElapsed_++;
  std::cout << "~~~~~~~~~~ The time is now " << simulationTimeElapsed_;
  std::cout << "~~~~~~~~~~" << std::endl;
  std::cout << "~~~~~~~~~~ Generating new busses if needed ";
  std::cout << "~~~~~~~~~~" << std::endl;
  // busFactory = new BusFactory();
  // Check if we need to generate new busses
  Bus* tempBus;
  for (int i = 0; i < static_cast<int>(timeSinceLastBus_.size()); i++) {
  // Check if we need to make a new bus
    if (0 >= timeSinceLastBus_[i]) {
      Route * outbound = prototypeRoutes_[2 * i];
      Route * inbound = prototypeRoutes_[2 * i + 1];
      // busses_.push_back(new Bus(std::to_string(busId), outbound->Clone(),
      // inbound->Clone(), 60, 1));
      tempBus = busFactory.Generate(std::to_string(busId),
        outbound->Clone(), inbound->Clone(), 1);
      busses_.push_back(tempBus);
      //  ibusses_.push_back(busFactory.Generate(std::to_string(busId),
      //    outbound->Clone(), inbound->Clone(), 1));
      ibusses_.push_back(tempBus);
      busId++;
      timeSinceLastBus_[i] = busStartTimings_[i];
    } else {
      timeSinceLastBus_[i]--;
    }
  }
  std::cout << "~~~~~~~~~ Updating busses ";
  std::cout << "~~~~~~~~~" << std::endl;
  // Update busses
  for (int i = static_cast<int>(busses_.size()) - 1; i >= 0; i--) {
    busses_[i]->Update();
    if (busses_[i]->IsTripComplete()) {
      webInterface_->UpdateBus(busses_[i]->GetBusData(), true);
      busses_.erase(busses_.begin() + i);
      ibusses_.erase(ibusses_.begin() + i);
      continue;
    }
    webInterface_->UpdateBus(busses_[i]->GetBusData());
    std::ostringstream ss2;
    std::vector<std::string> contents;
    busses_[i]->Report(ss2);
    contents = Util::processOutput(ss2);
    FileWriterManager fwm;
    FileWriter fw = fwm.getInstance();
    fw.Write("BusData.csv", contents);
  }
  std::cout << "~~~~~~~~~ Updating routes ";
  std::cout << "~~~~~~~~~" << std::endl;
  // Update routes
  for (int i = 0; i < static_cast<int>(prototypeRoutes_.size()); i++) {
    prototypeRoutes_[i]->Update();
    webInterface_->UpdateRoute(prototypeRoutes_[i]->GetRouteData());
    prototypeRoutes_[i]->Report(std::cout);
  }

  // Update stops
  // for (std::list<Stop *>::iterator it = stops_.begin();
  //   it != stops_.end(); it++) {
    // RouteData tempRouteData = route_data_;
  //   std::vector<StopData> tempStopData = tempRouteData.stops;
  //   for (unsigned int i = 0; i < tempStopData.size(); i++) {
  //     if (tempStopData.at(i).id.compare
  //       (std::to_string((*it)->GetId())) == 0) {
  //       StopData tempData = tempStopData.at(i);
  //       (*it)->NotifyObservers(&tempData);
  //     }
  //   }
  // }
}

// Pause VisualizationSimulator
void VisualizationSimulator::Pause() {
  if (is_prog_running == true)
    is_bus_pause = !is_bus_pause;
  else    return;
}

// Clear listeners
void VisualizationSimulator::ClearListeners() {
  for (unsigned int i = 0; i < busses_.size(); i++)
    busses_.at(i) -> ClearObservers();
}

// Clear stop listeners
void VisualizationSimulator::ClearStopListeners() {
  for (unsigned int i = 0; i < prototypeRoutes_.size(); i++) {
    Route* tempRoute = prototypeRoutes_.at(i);
    std::list<Stop*> tempStopsList = tempRoute->GetStops();
    std::list<Stop*>::iterator it;
    for (it = tempStopsList.begin(); it != tempStopsList.end(); it++) {
      (*it)->ClearObservers();
    }
  }
}

// Add Listeners
void VisualizationSimulator::AddListener(std::string* bus_id_,
  IObserver<BusData*> *observer_) {
  for (unsigned int i = 0; i < busses_.size(); i++) {
    if ((busses_.at(i) -> GetName()).compare(*bus_id_) == 0) {
      busses_.at(i) -> RegisterObserver(observer_);
      // busses_.at(i) -> NotifyObservers(busses_.at(i) -> GetBusData());
    }
  }
}

// Add Stop Listeners
void VisualizationSimulator::AddStopListener(int stop_id_,
  IObserver<StopData*> *observer_) {
  for (unsigned int i = 0; i < prototypeRoutes_.size(); i++) {
    Route* tempRoute = prototypeRoutes_.at(i);
    std::list<Stop*> tempStopsList = tempRoute->GetStops();
    std::list<Stop*>::iterator it;
    for (it = tempStopsList.begin(); it != tempStopsList.end(); it++) {
      if ((*it)->GetId() == stop_id_)
        (*it)->RegisterObserver(observer_);
    }
  }
}
