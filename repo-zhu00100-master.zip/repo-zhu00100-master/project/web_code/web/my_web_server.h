/**
 * @file my_web_server.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#ifndef WEB_MY_WEB_SERVER_H_
#define WEB_MY_WEB_SERVER_H_

/*******************************************************************************
  * Includes
******************************************************************************/
#include <vector>

#include "web_code/web/web_interface.h"

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
 * @brief This class is for MyWebServer
 *
 */
class MyWebServer : public WebInterface {
 public:
  /**
  * @brief public members of MyWebServer
  */
  /**
  * @brief construcor for MyWebServer class.
  *
  * @return no return value
  */
  MyWebServer();
  /**
  * @brief deconstrucor for MyWebServer class.
  *
  * @return no return value
  */
  ~MyWebServer() {}
  /**
  * @brief This function is to update routes
  *
  * @param[in] route specify the route
  * @param[in] deleted jugde if route is existed
  *
  * @return void
  */
  void UpdateRoute(const RouteData& route, bool deleted = false) override;
  /**
  * @brief This function is to update bus
  *
  * @param[in] bus specify the bus
  * @param[in] deleted jugde if bus is existed
  *
  * @return void
  */
  void UpdateBus(const BusData& bus, bool deleted = false) override;
  /**
  * @brief an array of routes
  */
  std::vector<RouteData> routes;
  /**
  * @brief an array of busses
  */
  std::vector<BusData> busses;
};

#endif  // WEB_MY_WEB_SERVER_H_
