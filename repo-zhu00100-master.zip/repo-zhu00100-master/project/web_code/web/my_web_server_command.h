/**
 * @file my_web_server_command.h
 *
 * @copyright 2019 boss, All rights reserved.
 */
#ifndef WEB_MY_WEB_SERVER_COMMAND_H_
#define WEB_MY_WEB_SERVER_COMMAND_H_

/*******************************************************************************
  * Includes
******************************************************************************/
#include <vector>
#include <sstream>

#include "src/config_manager.h"
#include "src/data_structs.h"

#include "web_code/web/visualization_simulator.h"
#include "web_code/web/my_web_server_session.h"
#include "web_code/web/my_web_server_session_state.h"
#include "web_code/web/my_web_server.h"

class MyWebServerSession;
class MyWebServerSessionState;

/*******************************************************************************
* Class Definitions
******************************************************************************/
/**
* @brief This class is for MyWebServerCommand
*/
class MyWebServerCommand {
 public:
  /**
  * @brief public members of MyWebServerCommand
  */
  /**
  * @brief deconstrucor for MyWebServerCommand class.
  *
  * @return no return value
  */
  virtual ~MyWebServerCommand() {}
  /**
  * @brief This function is to execute command needs ob overrided
  * @param[in] session webserver session
  * @param[in] command command in JSON
  * @param[in] state session state
  * @return void
  */
  virtual void execute(MyWebServerSession* session,
    picojson::value& command, MyWebServerSessionState* state) = 0;  //NOLINT
};

/********** COMMANDS ***********/
/*******************************************************************************
* Class Definitions
******************************************************************************/
/**
* @brief This class is for GetRoutesCommand
*/
class GetRoutesCommand : public MyWebServerCommand {
 public:
  /**
  * @brief public members of GetRoutesCommand
  */
  /**
  * @brief construcor for GetRoutesCommand class.
  *
  * @param[in] ws web server
  * @return no return value
  */
  explicit GetRoutesCommand(MyWebServer* ws);
  /**
  * @brief This function is to execute command needs ob overrided
  * @param[in] session webserver session
  * @param[in] command command in JSON
  * @param[in] state session state
  * @return void
  */
  void execute(MyWebServerSession* session,
   picojson::value& command, MyWebServerSessionState* state) override;

 private:
  /**
  * @brief private members of GetRoutesCommand
  */
  /**
  * @brief web server
  */
  MyWebServer* myWS;
};

/********** COMMANDS ***********/
/*******************************************************************************
* Class Definitions
******************************************************************************/
/**
* @brief This class is for GetBussesCommand
*/
class GetBussesCommand : public MyWebServerCommand {
 public:
  /**
  * @brief public members of GetBussesCommand
  */
  /**
  * @brief construcor for GetBussesCommand class.
  *
  * @param[in] ws web server
  * @return no return value
  */
  explicit GetBussesCommand(MyWebServer* ws);
  /**
  * @brief This function is to execute command needs ob overrided
  * @param[in] session webserver session
  * @param[in] command command in JSON
  * @param[in] state session state
  * @return void
  */
  void execute(MyWebServerSession* session,
   picojson::value& command, MyWebServerSessionState* state) override;

 private:
  /**
  * @brief private members of GetBussesCommand
  */
  /**
  * @brief web server
  */
  MyWebServer* myWS;
};

/********** COMMANDS ***********/
/*******************************************************************************
* Class Definitions
******************************************************************************/
/**
* @brief This class is for StartCommand
*/
class StartCommand : public MyWebServerCommand {
 public:
  /**
  * @brief public members of StartCommand
  */
  /**
  * @brief construcor for StartCommand class.
  *
  * @param[in] sim visualization simulator
  * @return no return value
  */
  explicit StartCommand(VisualizationSimulator* sim);
  /**
  * @brief This function is to execute command needs ob overrided
  * @param[in] session webserver session
  * @param[in] command command in JSON
  * @param[in] state session state
  * @return void
  */
  void execute(MyWebServerSession* session,
   picojson::value& command, MyWebServerSessionState* state) override;

 private:
  /**
  * @brief private members of StartCommand
  */
  /**
  * @brief visulization simulator
  */
  VisualizationSimulator* mySim;
  /**
  * @brief an array of time gaps between busses
  */
  std::vector<int> timeBetweenBusses;
  /**
  * @brief numbers of time steps
  */
  int numTimeSteps;
};

/********** COMMANDS ***********/
/*******************************************************************************
* Class Definitions
******************************************************************************/
/**
* @brief This class is for UpdateCommand
*/
class UpdateCommand : public MyWebServerCommand {
 public:
   /**
  * @brief public members of UpdateCommand
  */
  /**
  * @brief construcor for UpdateCommand class.
  *
  * @param[in] sim visualization simulator
  * @return no return value
  */
  explicit UpdateCommand(VisualizationSimulator* sim);
  /**
  * @brief This function is to execute command needs ob overrided
  * @param[in] session webserver session
  * @param[in] command command in JSON
  * @param[in] state session state
  * @return void
  */
  void execute(MyWebServerSession* session,
   picojson::value& command, MyWebServerSessionState* state) override;

 private:
  /**
  * @brief private members of UpdateCommand
  */
  /**
  * @brief visulization simulator
  */
  VisualizationSimulator* mySim;
};

/********** COMMANDS ***********/
/*******************************************************************************
* Class Definitions
******************************************************************************/
/**
* @brief This class is for InitRoutesCommand
*/
class InitRoutesCommand : public MyWebServerCommand {
 public:
  /**
  * @brief public members of InitRoutesCommand
  */
  /**
  * @brief construcor for InitRoutesCommand class.
  *
  * @param[in] cm config manager
  * @return no return value
  */
  explicit InitRoutesCommand(ConfigManager* cm);
  /**
  * @brief This function is to execute command needs ob overrided
  * @param[in] session webserver session
  * @param[in] command command in JSON
  * @param[in] state session state
  * @return void
  */
  void execute(MyWebServerSession* session,
   picojson::value& command, MyWebServerSessionState* state) override;

 private:
  /**
  * @brief private members of InitRoutesCommand
  */
  /**
  * @brief config manager
  */
  ConfigManager* cm;
};

/********** COMMANDS ***********/
/*******************************************************************************
* Class Definitions
******************************************************************************/
/**
* @brief This class is for PauseCommand
*/
class PauseCommand : public MyWebServerCommand {
 public:
  /**
  * @brief public members of PauseCommand
  */
  /**
  * @brief construcor for PauseCommand class.
  *
  * @param[in] sim visualization simulator
  * @return no return value
  */
  explicit PauseCommand(VisualizationSimulator* sim);
  /**
  * @brief This function is to execute command needs ob overrided
  * @param[in] session webserver session
  * @param[in] command command in JSON
  * @param[in] state session state
  * @return void
  */
  void execute(MyWebServerSession* session,
   picojson::value& command, MyWebServerSessionState* state) override;

 private:
  /**
  * @brief private members of PauseCommand
  */
  /**
  * @brief visulization simulator
  */
  VisualizationSimulator* mySim;
};

/********** COMMANDS ***********/
/*******************************************************************************
* Class Definitions
******************************************************************************/
/**
* @brief This class is for AddListenerCommand
*/
class AddListenerCommand: public MyWebServerCommand {
 public:
  /**
  * @brief public members of AddListenerCommand
  */
  /**
  * @brief construcor for AddListenerCommand class.
  *
  * @param[in] sim visualization simulator
  * @return no return value
  */
    explicit AddListenerCommand(VisualizationSimulator* sim);
  /**
  * @brief This function is to execute command needs ob overrided
  * @param[in] session webserver session
  * @param[in] command command in JSON
  * @param[in] state session state
  * @return void
  */
    void execute(MyWebServerSession* session, picojson::value& command,
      MyWebServerSessionState* state) override;

 private:
  /**
  * @brief private members of PauseCommand
  */
  /**
  * @brief visulization simulator
  */
    VisualizationSimulator* mySim;
};

/********** COMMANDS ***********/
/*******************************************************************************
* Class Definitions
******************************************************************************/
/**
* @brief This class is for BusWebObserver
*/
class BusWebObserver : public IObserver<BusData*> {
 public:
  /**
  * @brief public members of BusWebObserver
  */
  /**
  * @brief construcor for BusWebObserver class.
  *
  * @param[in] session web server session
  * @return no return value
  */
    explicit BusWebObserver(MyWebServerSession* session) : session(session) {}
  /**
  * @brief This function is to notify bus data
  * @param[in] info The bus data
  * @return void
  */
    void Notify(BusData* info) {
      // This normally called update, but we call it
      // Notify as per the lab writeup
      picojson::object data;
      data["command"] = picojson::value("observeBus");
      std::stringstream ss;
      ss << "Bus " << info->id << "\n";
      ss << "-----------------------------\n";
      ss << "  * Position: (" << info->position.x <<
       "," << info->position.y << ")\n";
      ss << "  * Passnegers: " << info->num_passengers << "\n";
      ss << "  * Capacity: " << info->capacity << "\n";
      data["text"] = picojson::value(ss.str());
      picojson::value ret(data);
      session->sendJSON(ret);
    }

 private:
  /**
  * @brief private members of BusWebObserver
  */
  /**
  * @brief session the web server session
  */
    MyWebServerSession* session;
};
/********** COMMANDS ***********/
/*******************************************************************************
* Class Definitions
******************************************************************************/
/**
* @brief This class is for AddStopListenerCommand
*/
class AddStopListenerCommand: public MyWebServerCommand {
 public:
  /**
  * @brief public members of AddStopListenerCommand
  */
  /**
  * @brief construcor for AddStopListenerCommand class.
  *
  * @param[in] sim visualization simulator
  * @return no return value
  */
    explicit AddStopListenerCommand(VisualizationSimulator* sim);
  /**
  * @brief This function is to execute command needs ob overrided
  * @param[in] session webserver session
  * @param[in] command command in JSON
  * @param[in] state session state
  * @return void
  */
    void execute(MyWebServerSession* session, picojson::value& command,
      MyWebServerSessionState* state) override;

 private:
  /**
  * @brief private members of PauseCommand
  */
  /**
  * @brief visulization simulator
  */
    VisualizationSimulator* mySim;
};


/********** COMMANDS ***********/
/*******************************************************************************
* Class Definitions
******************************************************************************/
/**
* @brief This class is for StopWebObserver
*/
class StopWebObserver : public IObserver<StopData*> {
 public:
  /**
  * @brief public members of StopWebObserver
  */
  /**
  * @brief construcor for StopWebObserver class.
  *
  * @param[in] session web server session
  * @return no return value
  */
    explicit StopWebObserver(MyWebServerSession* session) : session(session) {}
  /**
  * @brief This function is to notify bus data
  * @param[in] info The bus data
  * @return void
  */
    void Notify(StopData* info) {
      // This normally called update, but we call it
      // Notify as per the lab writeup
      picojson::object data;
      data["command"] = picojson::value("observeStop");
      std::stringstream ss;
      ss << "Stop " << info->id << "\n";
      ss << "-----------------------------\n";
      ss << "  * Position: (" << info->position.x <<
       "," << info->position.y << ")\n";
      ss << "  * Passnegers: " << info->num_people << "\n";
      // ss << "  * Capacity: " << info->capacity << "\n";
      data["text"] = picojson::value(ss.str());
      picojson::value ret(data);
      session->sendJSON(ret);
    }

 private:
  /**
  * @brief private members of StopWebObserver
  */
  /**
  * @brief session the web server session
  */
  MyWebServerSession* session;
};
#endif  // WEB_MY_WEB_SERVER_COMMAND_H_
