/**
 * @file web_interface.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#ifndef WEB_WEB_INTERFACE_H_
#define WEB_WEB_INTERFACE_H_

/*******************************************************************************
  * Includes
******************************************************************************/
#include "src/data_structs.h"
#include "src/bus_factory.h"
#include "src/route.h"

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
 /**
 * @brief This abstract class is for WebInterface
 */
class WebInterface {
 public:
  /**
  * @brief public members of MyInterface
  */
  /**
  * @brief deconstrucor for WebInterface class.
  *
  * @return no return value
  */
    virtual ~WebInterface() {}
  /**
  * @brief This abstract function is to update bus
  *
  * @param[in] bus specify the bus
  * @param[in] deleted jugde if bus is existed
  *
  * @return void
  */
    virtual void UpdateBus(const BusData& bus, bool deleted = false) = 0;
  /**
  * @brief This abstract function is to update route
  *
  * @param[in] route specify the route
  * @param[in] deleted jugde if route is existed
  *
  * @return void
  */
    virtual void UpdateRoute(const RouteData& route, bool deleted = false) = 0;
};

#endif  // WEB_WEB_INTERFACE_H_
