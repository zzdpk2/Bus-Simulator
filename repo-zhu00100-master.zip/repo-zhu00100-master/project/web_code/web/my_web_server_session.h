/**
 * @file my_web_server_session.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#ifndef WEB_MY_WEB_SERVER_SESSION_H_
#define WEB_MY_WEB_SERVER_SESSION_H_

/*******************************************************************************
  * Includes
******************************************************************************/

#include "WebServer.h"
#include "web_code/web/my_web_server_session_state.h"

/*******************************************************************************
* Class Definitions
******************************************************************************/
/**
* @brief This class is for MyWebServerSession
*/
class MyWebServerSession : public JSONSession {
 public:
  /**
  * @brief public members of MyWebServerSession
  */
  /**
  * @brief construcor for Bus class.
  *
  * @param[in] s web server session state
  *
  * @return no return value
  */
  explicit MyWebServerSession(MyWebServerSessionState s) : state(s) {}
  /**
  * @brief deconstrucor for MyWebServerSession class.
  * 
  * @return no return value
  */
  ~MyWebServerSession() {}
  /**
  * @brief This function is to receive JSON
  * @param[in] val json variable
  * @return void
  */
  void receiveJSON(picojson::value& val) override;
  /**
  * @brief This function is to update session
  * @return void
  */
  void update() override {}

 private:
  /**
  * @brief private members of MyWebServerSession
  */
  /**
  * @brief web server session state
  */
  MyWebServerSessionState state;
};


#endif  // WEB_MY_WEB_SERVER_SESSION_H_
