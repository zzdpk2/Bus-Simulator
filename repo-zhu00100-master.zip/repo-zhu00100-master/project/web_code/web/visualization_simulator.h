/**
 * @file visualization_simulator.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#ifndef WEB_VISUALIZATION_SIMULATOR_H_
#define WEB_VISUALIZATION_SIMULATOR_H_

/*******************************************************************************
  * Includes
******************************************************************************/

#include <vector>
#include <list>
#include <random>
#include <iostream>
#include <string>
#include <sstream>
#include <algorithm>

#include "web_code/web/web_interface.h"
#include "src/config_manager.h"
#include "src/bus_factory.h"
#include "src/util.h"
#include "src/file_writer_manager.h"
#include "src/IBus.h"
#include "src/route.h"

class Route;
class Bus;
class Stop;
class BusFactory;

/*******************************************************************************
* Class Definitions
******************************************************************************/
/**
 * @brief This class is for VisualizationSimulator
 *
 */
class VisualizationSimulator {
 public:
  /**
  * @brief public members of visualization simulator
  */
  /**
  * @brief construcor for VisualizationSimulator class.
  *
  * @param[in] webI Web Interface
  * @param[in] configM config Manager
  * @return no return value
  */
    VisualizationSimulator(WebInterface*, ConfigManager*);
  /**
  * @brief deconstrucor for VisualizationSimulator class.
  *
  * @return no return value
  */
    ~VisualizationSimulator();
  /**
  * @brief This function is for starting simulization process.
  *
  * @param[in] busStartTimings record bus start timings
  * @param[in] numTimeSteps record number of time steps
  * @return void
  */
    void Start(const std::vector<int>&, const int&);
  /**
  * @brief This function is updating simulator.
  *
  * @return void
  */
    void Update();
  /**
  * @brief This function is pausing and resuming the simulator.
  *
  * @return void
  */
    void Pause();
  /**
  * @brief This function is for clearing listeners.
  *
  * @return void
  */
    void ClearListeners();
  /**
  * @brief This function is for adding listeners.
  *
  * @return void
  */
    void AddListener(std::string* bus_id_, IObserver<BusData*>* observer_);
  /**
  * @brief This function is for adding stop listeners.
  *
  * @return void
  */
    void ClearStopListeners();
  /**
  * @brief This function is for adding stop listeners.
  *
  * @return void
  */
    void AddStopListener(int stop_id_, IObserver<StopData*>* observer_);

 private:
  /**
  * @brief private members of visualization simulator
  */
  /**
  * @brief web interface
  */
    WebInterface* webInterface_;
  /**
  * @brief config manager
  */
    ConfigManager* configManager_;
  /**
  * @brief bus factory
  */
    BusFactory busFactory;
  /**
  * @brief an array of bus starting times
  */
    std::vector<int> busStartTimings_;
  /**
  * @brief an array of time since last bus
  */
    std::vector<int> timeSinceLastBus_;
  /**
  * @brief number of time steps
  */
    int numTimeSteps_;
  /**
  * @brief simulation time elapsed
  */
    int simulationTimeElapsed_;
  /**
  * @brief an array of prototype routes
  */
    std::vector<Route *> prototypeRoutes_;
  /**
  * @brief an array of busses
  */
    std::vector<Bus *> busses_;
  /**
  * @brief an array of ibusses
  */
    std::vector<IBus *> ibusses_;
  /**
  * @brief ID of busses
  */
    int busId = 1000;
  /**
  * @brief record the status of program
  */
    bool is_prog_running = false;
  /**
  * @brief record the status of bus
  */
    bool is_bus_pause = false;
};

#endif  // WEB_VISUALIZATION_SIMULATOR_H_
