/*
 * Students: Use this file as a guide to writing your own unit tests.
 * See the project instructions for more information on which classes
 * and methods must be tested.
 */

/*******************************************************************************
 * Includes
 ******************************************************************************/
#include <gtest/gtest.h>

#include <iostream>
#include <string>
#include <list>
#include <string>

#include "../src/passenger_loader.h"
#include "../src/passenger_unloader.h"
#include "../src/passenger.h"
#include "../src/stop.h"

using namespace std;

/******************************************************
* TEST FEATURE SetUp
*******************************************************/
class PassengerTests : public ::testing::Test {
protected:
  // Set up data
  PassengerLoader* pass_loader;
  PassengerUnloader* pass_unloader;
  Passenger *passenger, *passenger1, *passenger2;

  virtual void SetUp() {
    // Init data
    pass_loader = new PassengerLoader();
    pass_unloader = new PassengerUnloader();
  }

  virtual void TearDown() {
    // delete
    delete pass_loader;
    delete pass_unloader;
    delete passenger;
    passenger = NULL;
    pass_loader = NULL;
    pass_unloader = NULL;
  }
};


/*******************************************************************************
 * Test Cases
 ******************************************************************************/
// Test constructor
TEST_F(PassengerTests, Constructor) {
  passenger = new Passenger();
  ASSERT_FALSE(passenger->IsOnBus())
      << "Constructor with no param failed";
  ASSERT_EQ(passenger->GetTotalWait(), 0)
    << "Constructor with no param failed";

  passenger->GetOnBus();
  ASSERT_TRUE(passenger->IsOnBus())
    << "Constructor with no param failed";
  ASSERT_EQ(passenger->GetTotalWait(), 1)
    << "Constructor with no param failed";

  passenger = new Passenger(2, "Amazon");
  ASSERT_FALSE(passenger->IsOnBus())
    << "Constructor with 2 params failed";
  ASSERT_EQ(passenger->GetTotalWait(), 0)
    << "Constructor with 2 params failed";

  passenger->GetOnBus();
  ASSERT_TRUE(passenger->IsOnBus())
    << "Constructor with 2 params failed";;
  ASSERT_EQ(passenger->GetTotalWait(), 1)
    << "Constructor with 2 params failed";
};

TEST_F(PassengerTests, Update) {
  passenger = new Passenger();
  passenger->GetOnBus();

  passenger->Update();
  EXPECT_EQ(passenger->GetTotalWait(), 2) << "Update failed";

  passenger = new Passenger(2, "Google");
  passenger->Update();
  EXPECT_EQ(passenger->GetTotalWait(), 1) << "Update failed";
};

TEST_F(PassengerTests, GetOnBus) {
  passenger = new Passenger();
  EXPECT_EQ(passenger->GetTotalWait(), 0) << "GetOnBus() Failed";
  passenger->GetOnBus();
  EXPECT_EQ(passenger->GetTotalWait(), 1) << "GetOnBus() failed";

  passenger = new Passenger(1, "Facebook");
  EXPECT_EQ(passenger->GetTotalWait(), 0) << "GetOnBus() Failed";
  passenger->GetOnBus();
  EXPECT_EQ(passenger->GetTotalWait(), 1) << "GetOnBus() failed";

};

TEST_F(PassengerTests, GetTotalWait) {
  passenger = new Passenger();
  EXPECT_EQ(passenger->GetTotalWait(), 0) << "GetTotalWait() failed";

  passenger = new Passenger(1, "LinkedIn");
  EXPECT_EQ(passenger->GetTotalWait(), 0) << "GetTotalWait() failed";

};

TEST_F(PassengerTests, IsOnBus){
  passenger = new Passenger();
  EXPECT_EQ(passenger->IsOnBus(), false) << "IsOnBus() failed";
  passenger->GetOnBus();
  EXPECT_EQ(passenger->IsOnBus(), true) << "IsOnBus() failed";
};

TEST_F(PassengerTests, GetDestination) {
  passenger = new Passenger();
  EXPECT_EQ(passenger->GetDestination(), -1) << "GetDestination() failed";

  passenger = new Passenger(1, "Tik-Tok");
  EXPECT_EQ(passenger->GetDestination(), 1) << "GetDestination() failed";
};

TEST_F(PassengerTests, Report) {

  // Name check
  passenger1 = new Passenger(12,"John Doe");
  passenger2 = new Passenger(12,"Apple Bee");
  std::string expected_output_1 = "Name: John Doe";
  std::string expected_output_2 = "Name: Apple Bee";
  testing::internal::CaptureStdout();
  passenger1->Report(std::cout);
  std::string output1 = testing::internal::GetCapturedStdout();
  testing::internal::CaptureStdout();
  passenger2->Report(std::cout);
  std::string output2 = testing::internal::GetCapturedStdout();
  int p1 = output1.find(expected_output_1);
  int p2 = output2.find(expected_output_2);
  EXPECT_GE(p1, 0);
  EXPECT_GE(p2, 0);

  // Destination check
  EXPECT_EQ(passenger1->GetDestination(), 12) << "Report failed!";
  EXPECT_EQ(passenger2->GetDestination(), 12) << "Report failed!";

  // Total wait check
  EXPECT_EQ(passenger1->GetTotalWait(), 0) << "Report failed!";
  EXPECT_EQ(passenger2->GetTotalWait(), 0) << "Report failed!";

  // Wait at stop check
  EXPECT_EQ(passenger2->GetTotalWait(), 0) << "Report failed!";

  // Time on bus check
  passenger1->GetOnBus();
  EXPECT_EQ(passenger1->GetTotalWait(), 1) << "Report failed!";

};
