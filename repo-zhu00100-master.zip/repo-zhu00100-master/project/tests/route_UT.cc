#include <gtest/gtest.h>

#include <iostream>
#include <string>
#include <list>
#include <string>

#include "../src/passenger_loader.h"
#include "../src/passenger_unloader.h"
#include "../src/passenger_generator.h"
#include "../src/random_passenger_generator.h"
#include "../src/passenger.h"
#include "../src/stop.h"
#include "../src/data_structs.h"
#include "../src/route.h"

using namespace std;

class RouteTests : public :: testing :: Test {
  protected:
    // Required data for route
    Route* route;
    Stop* stop1;
    Stop* stop2;
    Stop* stop3;
    Stop* stop4;
    Stop** stops;
    double* distances;
    PassengerGenerator* pg;
    std::list<double> probs;
    std::list<Stop*> stop_list;

    virtual void SetUp() {
      // Set up init value
      // Set up data set for stops
      stop1 = new Stop(1, 11.1, 22.2);
      stop2 = new Stop(2, 33.3, 44.4);
      stop3 = new Stop(3, 55.5, 66.6);
      stop4 = new Stop(4, 77.7, 88.8);

      stops = new Stop*[4];
      stops[0] = stop1;
      stops[1] = stop2;
      stops[2] = stop3;
      stops[3] = stop4;

      // Set up distances
      distances = new double[3];
      distances[0] = 1.5;
      distances[1] = 2.5;
      distances[2] = 3.5;

      for (int i = 0; i < 4; i++)
        stop_list.push_back(stops[i]);
      
      // Set up probabilties 
      probs.push_back(0.3);
      probs.push_back(0.2);
      probs.push_back(0.8);
      probs.push_back(0.6);

      // Set up a generator
      pg = new RandomPassengerGenerator(probs, stop_list);

      // Set up route
      route = new Route("route_test", stops, distances, stop_list.size(), pg);
    }

    virtual void TearDown() {
      // delete
      delete stop1;
      delete stop2;
      delete stop3;
      delete distances;
      delete route;
      delete stops;

      // point to NULL
      stop1 = NULL;
      stop2 = NULL;
      stop3 = NULL;
      distances = NULL;
      route = NULL;
      stops = NULL;
    }
};

TEST_F(RouteTests, Constructor) {
  EXPECT_EQ(route->GetName(), "route_test") 
    << "Constructor failed";

  EXPECT_EQ(route->GetDestinationStop()->GetId(), 1) 
    << "Constructor failed";
  EXPECT_EQ(route->GetDestinationStop()->GetLongitude(), 11.1) 
    << "Constructor failed";
  EXPECT_EQ(route->GetDestinationStop()->GetLatitude(), 22.2) 
    << "Constructor failed";

  EXPECT_EQ(route->GetStops(), stop_list) 
    << "Constructor failed";
  EXPECT_EQ(route->GetTotalRouteDistance(), 6.0) 
    << "Constructor failed";
  EXPECT_EQ(route->GetNextStopDistance(), 0) 
    << "Constructor failed";
};

TEST_F(RouteTests, PrevStop) {
  EXPECT_EQ(route->PrevStop()->GetId(), 1) 
    << "PrevStopTest failed";
  EXPECT_EQ(route->PrevStop()->GetLongitude(), 11.1) 
    << "PrevStopTest failed";
  EXPECT_EQ(route->PrevStop()->GetLatitude(), 22.2) 
    << "PrevStopTest failed";
};

TEST_F(RouteTests, IsAtEnd) {
  EXPECT_EQ(route->IsAtEnd(), false) << "IsAtEnd() failed";
};

TEST_F(RouteTests, GetDestinationStop) {
  EXPECT_EQ(route->GetDestinationStop()->GetId(), 1) 
    << "GetDestinationStop()) failed";
};

TEST_F(RouteTests, GetTotalRouteDistance) {
  EXPECT_EQ(route->GetTotalRouteDistance(), 6.0) 
    << "GetTotalRouteDistance failed";
};

TEST_F(RouteTests, GetNextStopDistance) {
  EXPECT_EQ(route->GetNextStopDistance(), 0.0) 
    << "GetNextStopDistance() failed";
};

TEST_F(RouteTests, GetName) {
  EXPECT_EQ(route->GetName(), "route_test") 
    << "GetName() failed";
};

TEST_F(RouteTests, GetStops) {
  EXPECT_EQ(route->GetStops(), stop_list) 
  << "GetStops failed";
};

TEST_F(RouteTests, GetRouteData) {
  EXPECT_EQ(route->GetRouteData().id, "")
  << "GetRouteData failed";
};
