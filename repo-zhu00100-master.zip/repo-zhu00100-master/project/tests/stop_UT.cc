#include <gtest/gtest.h>

#include <iostream>
#include <string>
#include <list>
#include <string>

#include "../src/passenger_loader.h"
#include "../src/passenger_unloader.h"
#include "../src/passenger.h"
#include "../src/stop.h"

using namespace std;

class StopTests : public ::testing::Test {
 protected:
  // Set up stops
  Stop* stop1;
  Stop* stop2;
    
  virtual void SetUp() {
    // Init data
    stop1 = new Stop(0, 11.11, 12.22);
    stop2 = new Stop(1, 22.33, 44.11);
  }

  virtual void TearDown() {
    // delete
    delete stop1;
    delete stop2;

    // point to NULL
    stop1 = NULL;
    stop2 = NULL;
  }
};

// Constructor test 1
TEST_F(StopTests, Constructor1) {
  Stop* testStop = new Stop(4, 22.2, 62.2);
  EXPECT_EQ(testStop->GetId(), 4) 
    << "Constructor failed";
};

// Constructor test 2
TEST_F(StopTests, Constructor2) {
  Stop* testStop_1 = new Stop(4, 22.2, 62.2);
  int id = testStop_1->GetId();
  double longitude = testStop_1->GetLongitude();
  double latitude = testStop_1->GetLatitude();
  bool result = false;
  if (id == 4){
    if(longitude == 22.2) {
      if (latitude == 62.2) {
        result = true;
      }
      else 
        result = false;
    }
    else 
      result = false; 
  } else
    result = false;
  EXPECT_EQ(result, true) 
    << "Constructor failed";
};

TEST_F(StopTests, GetId) {
  EXPECT_EQ(stop1->GetId(), 0) 
    << "GetId() failed";
  EXPECT_EQ(stop2->GetId(), 1) 
    << "GetId() failed"; 
};

TEST_F(StopTests, GetLongitude) {
  stop1 = new Stop(0, 11.11, 12.22);
  EXPECT_EQ(stop1->GetLongitude(), 11.11) 
    << "GetLongitude() failed";
};

TEST_F(StopTests, GetLatitude) {
  stop1 = new Stop(0, 11.11, 12.22);
  EXPECT_EQ(stop1->GetLatitude(), 12.22) 
    << "GetLatitude() failed";
};

TEST_F(StopTests, GetNumPassengersPresent) {
  Passenger* passengers_0 = new Passenger(1, "A");
  Passenger* passengers_1 = new Passenger(2, "B");
  Passenger* passengers_2 = new Passenger(3, "C");
  stop1->AddPassengers(passengers_0);
  stop1->AddPassengers(passengers_1);
  stop1->AddPassengers(passengers_2);
  EXPECT_EQ(stop1->GetNumPassengersPresent(), 3) 
    << "GetNumPassengersPresent() failed";
};
