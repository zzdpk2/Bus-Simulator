#include <gtest/gtest.h>

#include <iostream>
#include <string>
#include <list>
#include <string>

#include "../src/passenger_loader.h"
#include "../src/passenger_unloader.h"
#include "../src/passenger.h"
#include "../src/passenger_generator.h"
#include "../src/random_passenger_generator.h"

#include "../src/stop.h"
#include "../src/bus.h"

using namespace std;
// GTEST_BREAK_ON_FAILURE=1;

class BusTests : public ::testing::Test {
  protected:
    // Out route data
    Route* route_out;
    Stop** stops_out;

    Stop* stop1_out;
    Stop* stop2_out;
    Stop* stop3_out;

    double* distances_out;
    RandomPassengerGenerator* pg_out;
    std::list<double> probs_out;
    std::list<Stop*> stop_list_out;
    Bus* bus_out;
    Passenger* passenger_out;
    int out_capacity;
    double out_speed;

    // In route data
    Route* route_in;
    Stop** stops_in;

    Stop* stop1_in;
    Stop* stop2_in;
    Stop* stop3_in;

    double* distances_in;
    RandomPassengerGenerator* pg_in;
    std::list<double> probs_in;
    std::list<Stop*> stop_list_in;
    Bus* bus_in;
    Passenger* passenger_in;
    int in_capacity;
    double in_speed;

    virtual void SetUp() {
        // ----------------- Out data -------------- //
        // Out stops init
        stop1_out = new Stop(1, 11.1, 22.2);
        stop2_out = new Stop(2, 33.3, 44.4);
        stop3_out = new Stop(3, 55.5, 66.6);

        // Out stops container init
        stops_out = new Stop*[3];
        stops_out[0] = stop1_out;
        stops_out[1] = stop2_out;
        stops_out[2] = stop3_out;

        // Init container with out data
        for (int i = 0; i < 3; i++)
            stop_list_out.push_back(stops_out[i]);

        // Out distance init
        distances_out = new double[2];
        distances_out[0] = 1.5;
        distances_out[1] = 2.5;

        // Out prob init
        probs_out.push_back(0.4);
        probs_out.push_back(0.6);
        probs_out.push_back(0.8);

        // Init passenger for out route
        pg_out = new RandomPassengerGenerator(probs_out, stop_list_out);

        // Init out route
        route_out = new Route("out_route", stops_out, distances_out, 3, pg_out);

        // Init out bus capacity
        out_capacity = 40;

        // Init out bus speed
        out_speed = 60;

        // Init in passenger
        passenger_out = new Passenger(1);

        // ----------------- In data -------------- //
        // In stops init
        stop1_in = new Stop(4, 55.55, 66.66);
        stop2_in = new Stop(5, 33.33, 44.44);
        stop3_in = new Stop(6, 11.11, 22.22);

        // In stops container
        stops_in = new Stop*[3];
        stops_in[0] = stop1_in;
        stops_in[1] = stop2_in;
        stops_in[2] = stop3_in;

        // Init in route distances
        distances_in = new double[2];
        distances_in[0] = 2.0;
        distances_in[1] = 3.0;

       // Init container with in data
        for (int i = 0; i < 3; i++)
            stop_list_in.push_back(stops_in[i]);

        // In prob init
        probs_in.push_back(0.5);
        probs_in.push_back(0.7);
        probs_in.push_back(0.9);

        // Init passenger for in route
        pg_in = new RandomPassengerGenerator(probs_in, stop_list_in);

        // Init in route
        route_in = new Route("in_route", stops_in, distances_in, 3, pg_in);

        // Init in capacity
        in_capacity = 30;

        // Init in speed
        in_speed = 70;

        // Init in passenger
        passenger_in = new Passenger(1);

        // ----------------- Cumulative data -------------- //

        // Init in bus
        bus_in = new Bus("222", route_in, route_out, in_capacity, in_speed);
        bus_out = new Bus("111", route_out, route_in, out_capacity, 2);
        
    }

    virtual void TearDown() {

      // Delete out
      delete stop1_out;
      delete stop2_out;
      delete stop3_out;

      delete[] stops_out;
      delete route_out;
      delete distances_out;
      // delete bus_out;
      delete passenger_out;

      // Point to NULL
      stop1_out = NULL;
      stop2_out = NULL;
      stop3_out = NULL;

      stops_out = NULL;
      route_out = NULL;
      distances_out = NULL;
      bus_out = NULL;
      passenger_out = NULL;

      // Delete in
      delete stop1_in;
      delete stop2_in;
      delete stop3_in;

      delete[] stops_in;
      delete route_in;
      delete distances_in;
      // delete bus_in;
      delete passenger_in;

      // Point to NULL
      stop1_in = NULL;
      stop2_in = NULL;
      stop3_in = NULL;

      stops_in = NULL;
      stops_in = NULL;
      stops_in = NULL;
      route_in = NULL;
      distances_in = NULL;
      pg_in = NULL;
      bus_in = NULL;
      passenger_in = NULL;

    }
};


TEST_F(BusTests, Constructor) {
  EXPECT_EQ(bus_out->GetName(), "111") 
    << "Bus name incorrect";
  EXPECT_EQ(bus_in->GetName(), "222") 
    << "Bus name incorrect";
  EXPECT_EQ(bus_out->GetCapacity(), 40) 
    << "Bus capacity incorrect";
  EXPECT_EQ(bus_in->GetCapacity(), 30) 
    << "Bus capacity incorrect";
};


TEST_F(BusTests, IsTripComplete) {
    ASSERT_FALSE(bus_out->IsTripComplete()) 
      << "IsTripComplete() failed";
    ASSERT_FALSE(bus_in->IsTripComplete()) 
      << "IsTripComplete() failed";
};

TEST_F(BusTests, IsTripComplete_1) {
    ASSERT_TRUE(!(bus_out->IsTripComplete())) 
      << "IsTripComplete() passed";
    ASSERT_TRUE(!(bus_in->IsTripComplete())) 
      << "IsTripComplete() passed";
}

TEST_F(BusTests, LoadPassenger) {
    ASSERT_TRUE(bus_out->LoadPassenger(passenger_out)) 
      << "LoadPassenger(Passenger *) failed";
    ASSERT_TRUE(bus_in->LoadPassenger(passenger_in)) 
      << "LoadPassenger(Passenger *) failed";
};

TEST_F(BusTests, Move) {
  bus_out->LoadPassenger(passenger_out);
  ASSERT_TRUE(bus_out->Move()) 
    << "Out bus first move failed";
  ASSERT_TRUE(bus_out->Move()) 
    << "Out second move failed";
  ASSERT_TRUE(bus_out->Move()) 
    << "Out third move failed";
  ASSERT_TRUE(bus_in->Move()) 
    << "In bus first move incorrect";
  ASSERT_TRUE(bus_in->Move()) 
    << "In bus second move incorrect";
};

TEST_F(BusTests, Move_2) {
  bus_out->LoadPassenger(passenger_out);
  ASSERT_FALSE(!(bus_out->Move())) 
    << "Out bus first move passed";
  ASSERT_FALSE(!(bus_out->Move())) 
    << "Out second move passed";
  ASSERT_FALSE(!(bus_out->Move())) 
    << "Out third move passed";
  ASSERT_TRUE((bus_in->Move()))
    << "In bus first move correct";
  ASSERT_FALSE(!(bus_in->Move())) 
    << "In bus second move correct";
};


TEST_F(BusTests, GetBusData) {
  EXPECT_EQ(bus_out->GetBusData().id, "") 
    << "Out bus data corrupted";
  EXPECT_EQ(bus_in->GetBusData().id, "") 
    << "In bus data corrupted";
  bus_out->Update();
  bus_in->Update();
  EXPECT_EQ(bus_out->GetBusData().id, "111") 
    << "Out bus data corrupted";
  EXPECT_EQ(bus_in->GetBusData().id, "222") 
    << "In bus data corrupted";
};

TEST_F(BusTests, GetName) {
  EXPECT_EQ(bus_out->GetName(), "111") 
    << "Out bus name corrupted";
  EXPECT_EQ(bus_in->GetName(), "222") 
    << "In bus name corrupted";
};

TEST_F(BusTests, GetNextStop) {
  EXPECT_EQ(bus_out->GetNextStop()->GetId(), 1) 
    << "Out route initialization failed";
  EXPECT_EQ(bus_in->GetNextStop()->GetId(), 4) 
    << "In route initialization failed";
};

TEST_F(BusTests, GetNumPassengers) {
  EXPECT_EQ(bus_out->GetNumPassengers(), 0) 
    << "Out passenger quantity corrupteed";
  EXPECT_EQ(bus_in->GetNumPassengers(), 0) 
    << "In passenger quantity corrupteed";
};

TEST_F(BusTests, GetCapacity) {
  EXPECT_EQ(bus_out->GetCapacity(), 40) 
    << "Bus capacity incorrect";
  EXPECT_EQ(bus_in->GetCapacity(), 30) 
    << "Bus capacity incorrect";
};

