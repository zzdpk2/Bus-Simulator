/**
 * @file file_writer.cc
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#include "src/file_writer_manager.h"

FileWriter FileWriterManager::getInstance() {
  return file_writer;
}
