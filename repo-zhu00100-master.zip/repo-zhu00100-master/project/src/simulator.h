/**
 * @file simulator.h
 *
 * @copyright 2020 3081 Staff, All rights reserved.
 */
#ifndef SRC_SIMULATOR_H_
#define SRC_SIMULATOR_H_

#include <list>
#include <vector>

#include "src/bus.h"
#include "src/stop.h"
#include "src/route.h"
#include "src/passenger_generator.h"

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
 * @brief This class is for Simulator
 */
class Simulator {
 public:
  /**
  * @brief public members of Simulator
  */
  /**
  * @brief start simlating (virtual)
  *
  * @return a bool to show if it is started. 
  */
  virtual bool Start() = 0;
  /**
  * @brief update simlating (virtual)
  *
  * @return a bool to show if it is updated. 
  */
  virtual bool Update() = 0;

 protected:
  /**
  * @brief protected members of Simulator
  */
  // bus and stop list will be iterated over to update
  // ist is efficient in traversal
  /**
  * @brief the list of active busses
  */
  std::list<Bus *> active_buses_;   // buses leave scope
  /**
  * @brief the list of all stops
  */
  std::list<Stop *> all_stops_;

  // prototype_routes and distance lists will be accessed directly
  // list is not efficient at direct selection by index
  // routes below a for copying on bus creation
  /**
  * @brief the array of routes
  */
  std::vector<Route *> prototype_routes_;
  /**
  * @brief the array of distances
  */
  std::vector<double *> distance_between_sets_;
  /**
  * @brief the array of PassengerGenerator
  */
  std::vector<PassengerGenerator *> passenger_generators_;
  // std::vector<std:list<double>> passenger_generation_probability_lists;
};

#endif  // SRC_SIMULATOR_H_
