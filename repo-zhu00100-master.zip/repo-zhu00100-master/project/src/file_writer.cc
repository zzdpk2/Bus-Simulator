/**
 * @file file_writer.cc
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#include "src/file_writer.h"

void FileWriter::Write(std::string file_name,
  std::vector<std::string> contents) {
  std::ofstream myfile_pass_data;
  myfile_pass_data.open(file_name,
    std::ofstream::out | std::ofstream::app);
  for (unsigned int i = 0; i < contents.size(); i++)
    myfile_pass_data << contents[i];
  myfile_pass_data.close();
}
