/**
 * @file file_writer.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#ifndef SRC_FILE_WRITER_H_
#define SRC_FILE_WRITER_H_

/*******************************************************************************
  * Includes
******************************************************************************/
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
/**
 * @brief This class is for FileWriter
 *
 */
/*******************************************************************************
* Class Definitions
******************************************************************************/
class FileWriter {
 public:
  /**
  * @brief public members of FileWriter
  */
  /**
  * @brief Write function
  *
  * @param[in] file_name the file name
  * @param[in] contents print contents
  *
  * @return void
  */
  void Write(std::string file_name, std::vector<std::string> contents);
};
#endif  // SRC_FILE_WRITER_H_
