/**
 * @file decorator.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#ifndef SRC_DECORATOR_H_
#define SRC_DECORATOR_H_

/*******************************************************************************
  * Includes
******************************************************************************/
#include "src/IBus.h"

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
* @brief This class is for Decorator
*
*/
class Decorator : public IBus {
 public:
  /**
  * @brief public members of Decorator
  */
  /**
  * @brief construcor for Decorator class.
  *
  * @param[in] ibus the ibus
  *
  * @return no return value
  */
  explicit Decorator(IBus* ibus);
  /**
  * @brief to modify color
  *
  * @return a int show status
  */
  int modifyColor();
 protected:
  /**
  * @brief to save ibus status
  */
  IBus* bus;
};
#endif  // SRC_DECORATOR_H_
