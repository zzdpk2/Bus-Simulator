/**
 * @file passenger_unloader.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */

#ifndef SRC_PASSENGER_UNLOADER_H_
#define SRC_PASSENGER_UNLOADER_H_

/*******************************************************************************
  * Includes
******************************************************************************/
#include <list>
#include <string>
#include "src/passenger.h"
#include "src/stop.h"
#include "src/file_writer_manager.h"
#include "src/util.h"
class Stop;
class Passenger;

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
 * @brief This class is for PassengerUnloader
 */
class PassengerUnloader {
 public:
  /**
  * @brief public members of bus factory
  */
  /**
  * @brief count unloaded passengers
  *
  * This function will be used for unloading passengers
  *
  * @param[in] passengers a list of passengers
  * @param[in] current_stop current stop
  * 
  * @return a int number representing unloaded passengers
  */
  // UnloadPassengers returns the number of passengers removed from the bus.
  int UnloadPassengers(std::list<Passenger*> passengers, Stop * current_stop);

 private:
  std::string passenger_file_name;
};
#endif  // SRC_PASSENGER_UNLOADER_H_
