/**
 * @file passenger_generator.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */

#ifndef SRC_PASSENGER_GENERATOR_H_
#define SRC_PASSENGER_GENERATOR_H_

/*******************************************************************************
  * Includes
******************************************************************************/

#include <list>
#include "src/passenger_factory.h"
#include "src/stop.h"

class Stop;  // forward declaration

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
 * @brief This class is for PassengerGenerator
 *
 * Calls to \ref PassengerGenerator function to get a new instance of a passenger.
 */
class PassengerGenerator {
 public:
  /**
  * @brief public members of passenger generator
  */
  /**
  * @brief Generation of passengers.
  *
  * @param[in] probs list of probabilities
  * @param[in] stops list of stops
  * @return no return value
  */
  PassengerGenerator(std::list<double>, std::list<Stop *>);
  // Makes the class abstract, cannot instantiate and forces subclass override
  /**
  * @brief Generation of passengers.
  *
  * This is a virtual function that needs to be overwritten.
  * @return a int to record return value
  */
  virtual int GeneratePassengers() = 0;  // pure virtual

 protected:
  /**
  * @brief protected members of passenger generator
  */
  /**
  * @brief std::list<double> generation_probabilities_ :
  * save the probabilities
  */
  std::list<double> generation_probabilities_;
  /**
  * @brief std::list<Stop *> stops_ : save the list
  */
  std::list<Stop *> stops_;
  // should we be using a singleton here somehow?
  // PassengerFactory * pass_factory;
};
#endif  // SRC_PASSENGER_GENERATOR_H_
