/**
 * @file data_structs.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#ifndef SRC_DATA_STRUCTS_H_
#define SRC_DATA_STRUCTS_H_

/*******************************************************************************
* Includes
******************************************************************************/
#include <string>
#include <vector>

/**
* @brief The data structure of Position
*/
struct Position {
    /** @struct Position
    *  This is a Position struct
    *
    *  @var Position::x
    *    distance on X axis
    *  @var Position::y
    *    distance on Y axis
    */
    Position() : x(0), y(0) {}
    float x;
    float y;
};

/**
* @brief The data structure of Color
*/
struct Color {
  /** @struct Color
  *  This is a Color struct
  *
  *  @var Color::red
  *    red value
  *  @var Color::green
  *    green value
  *  @var Color::blue
  *    blue value
  *  @var Color::alpha
  *    alpha value
  */
  /**
  * @brief construcor for Color.
  *
  * @param[in] r red value
  * @param[in] g green value
  * @param[in] b blue value
  * @param[in] a alpha value
  *
  * @return no return value
  */
  explicit Color(int r = 0, int g = 0, int b = 0, int a = 255):
    red(r), green(g), blue(b), alpha(a) { }
  int red;
  int green;
  int blue;
  int alpha;
};

/**
* @brief The data structure of BusData
*/
struct BusData {
  /** @struct BusData
  *  This is a BusData struct
  *  @var BusData::id
  *    ID of recorded Bus
  *  @var BusData::color
  *    color of recorded Bus
  *  @var BusData::position
  *    position of saved bus
  *  @var BusData::num_passengers
  *    number of passengers
  *  @var BusData::capacity
  *    number of capacity of current bus
  */
  /**
  * @brief construcor for BusData.
  *
  * @param[in] id bus id
  * @param[in] color color
  * @param[in] pos position
  * @param[in] n_pass num of pass
  * @param[in] cap cap value
  * @return no return value
  */
  BusData(std::string id, Color color, Position pos, int n_pass, int cap):
    id(id), position(pos), num_passengers(n_pass),
    capacity(cap), color(color) { }
  BusData() : id(""),
    position(Position()), num_passengers(0), capacity(0), color() {}
  std::string id;
  Position position;
  int num_passengers;
  int capacity;
  Color color;
};

/**
* @brief The data structure of StopData
*/
struct StopData {
  /** @struct StopData
  *  This is a StopData struct
  *  @var StopData::id
  *    ID of recorded stop
  *  @var StopData::position
  *    position of saved stop
  *  @var StopData::num_people
  *    number of people at bus stop
  */
  StopData() : id(""), position(Position()), num_people(0) {}
  std::string id;
  Position position;
  int num_people;
};

/**
* @brief The data structure of RouteData
*/
struct RouteData {
    /** @struct RouteData
    *  This is a RouteData struct
    *  @var RouteData::id
    *    ID of recorded stop
    *  @var RouteData::stops
    *    an array of saved stops
    */
    RouteData() : id(""), stops(std::vector<StopData>(0)) {}
    std::string id;
    std::vector<StopData> stops;
};
#endif  // SRC_DATA_STRUCTS_H_
