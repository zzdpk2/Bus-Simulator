/**
 * @file bus_factory.h
 *
 * @copyright 2019 3081 Boss, All rights reserved.
 */
#ifndef SRC_BUS_FACTORY_H_
#define SRC_BUS_FACTORY_H_

/*******************************************************************************
  * Includes
******************************************************************************/
#include <string>

#include "src/bus.h"
#include "src/route.h"
#include "src/bus_large.h"
#include "src/bus_regular.h"
#include "src/bus_small.h"

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
 * @brief This class is for BusFactory to generate busses
 *
 * Calls to \ref Generate function to get a new instance of a bus.
 * This is a static call, not requiring an instance to invoke the method.
 */
class BusFactory {
 public:
  /**
  * @brief public members of bus factory
  */
  /**
  * @brief Generation of a bus with a randomized type.
  *
  * This function will be used for generating busses.
  *
  * @param[in] bus_name Bus name
  * @param[in] out_route out route
  * @param[in] in_route in route
  * @param[in] speed bus speed
  * 
  * @return a new Bus instance
  */
  // Generate the bus
  static Bus* Generate(std::string bus_name,
   Route* out_route, Route* in_route, double speed);
  // static vars
  /**
  * @brief strategy 1 status
  */
  static int times_strategy_A;
  /**
  * @brief strategy 2 status
  */
  static int times_strategy_B;
  /**
  * @brief strategy 3 status
  */
  static int times_strategy_C;

 private:
  /**
  * @brief private members of bus factory
  */
  /**
  * @brief Generate large bus
  *
  * @param[in] bus_name the bus name
  * @param[in] out_route departure route
  * @param[in] in_route incomming route
  * @param[in] speed bus speed
  *
  * @return a new large bus
  */
  static LargeBus *
    LargeBusGenerate(std::string bus_name,
      Route* out_route, Route* in_route, double speed);
  /**
  * @brief Generate regular bus
  *
  * @param[in] bus_name the bus name
  * @param[in] out_route departure route
  * @param[in] in_route incomming route
  * @param[in] speed bus speed
  *
  * @return a new regular bus
  */
  static RegularBus *
    RegularBusGenerate(std::string bus_name, Route* out_route,
      Route* in_route, double speed);
  /**
  * @brief Generate small bus
  *
  * @param[in] bus_name the bus name
  * @param[in] out_route departure route
  * @param[in] in_route incomming route
  * @param[in] speed bus speed
  *
  * @return a new small bus
  */
  static SmallBus *
    SmallBusGenerate(std::string bus_name, Route* out_route,
      Route* in_route, double speed);
};

#endif  // SRC_BUS_FACTORY_H_
