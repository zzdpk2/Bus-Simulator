/**
 * @file bus_factory.cc
 *
 * @copyright 2019 Boss, All rights reserved.
 */

/*******************************************************************************
  * Includes
******************************************************************************/
#include <time.h>
#include <assert.h>
#include <random>
#include <string>
#include <iostream>

#include "src/bus_factory.h"

/*******************************************************************************
 * Member Variables
 ******************************************************************************/
int BusFactory::times_strategy_A = 0;
int BusFactory::times_strategy_B = 0;
int BusFactory::times_strategy_C = 0;

/*******************************************************************************
 * Member Functions
 ******************************************************************************/
Bus * BusFactory::Generate(std::string name,
  Route* out, Route* in, double speed) {
  // fetch time
  timespec time;
  clock_gettime(CLOCK_REALTIME, &time);  // time(NULL)
  tm nowTime;
  localtime_r(&time.tv_sec, &nowTime);
  std::cout << "Year: " << (nowTime.tm_year + 1900)
    << " Month: " << nowTime.tm_mon
    << " Day: " << nowTime.tm_mday
    << " Hour: " << nowTime.tm_hour
    << " Minute: " << nowTime.tm_min
    << " Second: " << nowTime.tm_sec << std::endl;
  int hours = nowTime.tm_hour;
  // strategy 1
  if (hours >= 6 && hours < 8) {
    std::cout << "Strategy 1 is running....... " << std::endl;
    if (times_strategy_A % 2 == 0) {
      times_strategy_A++;
      return SmallBusGenerate(name, out, in, speed);
    } else {
      times_strategy_A++;
      return RegularBusGenerate(name, out, in, speed);
    }
  } else if (hours >= 8 && hours < 15) {
    // strategy 2
    std::cout << "Strategy 2 is running....... " << std::endl;
    if (times_strategy_B % 2 == 0) {
      times_strategy_B++;
      return RegularBusGenerate(name, out, in, speed);
    } else {
      times_strategy_B++;
      return LargeBusGenerate(name, out, in, speed);
    }
  } else if (hours >= 15 && hours < 20) {
    // strategy 3
    std::cout << "Strategy 3 is running....... " << std::endl;
    if (times_strategy_C % 3 == 0) {
      times_strategy_C++;
      return SmallBusGenerate(name, out, in, speed);
    } else if (times_strategy_C % 3 == 1) {
      times_strategy_C++;
      return RegularBusGenerate(name, out, in, speed);
    } else {
      times_strategy_C++;
      return LargeBusGenerate(name, out, in, speed);}
  } else {
    // strategy 4
    std::cout << "Strategy 4 is running....... " << std::endl;
    return SmallBusGenerate(name, out, in, speed);
  }
  // generate random number
  std::random_device dev;
  std::mt19937 rng(dev());
  std::uniform_int_distribution<std::mt19937::result_type> dist1(1, 3);
  int type = dist1(rng);
  // determine the bus type and create
  if (type == 1)
    return LargeBusGenerate(name, out, in, speed);
  else if (type == 2)
    return RegularBusGenerate(name, out, in, speed);
  else if (type == 3)
    return SmallBusGenerate(name, out, in, speed);
  else
    assert(false);
  return NULL;
}

// generate large bus
LargeBus * BusFactory::LargeBusGenerate(std::string name,
  Route* out_route, Route* in_route, double speed) {
  return new LargeBus(name, out_route, in_route, speed);
}

// generate regular bus
RegularBus * BusFactory::RegularBusGenerate(std::string name,
  Route* out, Route* in, double speed) {
  return new RegularBus(name, out, in, speed);
}

// generate small bus
SmallBus * BusFactory::SmallBusGenerate(std::string name,
  Route* out, Route* in, double speed) {
  return new SmallBus(name, out, in, speed);
}
