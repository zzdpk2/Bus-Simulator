/**
 * @file passenger.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#ifndef SRC_PASSENGER_H_
#define SRC_PASSENGER_H_

/*******************************************************************************
  * Includes
******************************************************************************/

#include <iostream>
#include <string>

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
 * @brief This class is for generating Passenger
 */
class Passenger {  // : public Reporter {
 public:
  /**
  * @brief public members of Passenger
  */
  /**
  * @brief constructor of Passenger class
  *
  * This function will be used for generating passenger.
  *
  * @param[in] destination_stop_id destination stop id of passenger
  * @param[in] name passenger name
  * 
  * @return a new Passenger instance
  */
  explicit Passenger(int = -1, std::string = "Nobody");
  /**
  * @brief update the passenger info
  * @return void
  */
  void Update();
  /**
  * @brief load the passenger onto a bus
  * @return void
  */
  void GetOnBus();
  /**
  * @brief update the total waiting time
  * @return a int to represent the total time of waiting
  */
  int GetTotalWait() const;
  /**
  * @brief judge the passenger is on the bus
  * @return a bool to show whether the passenger is on the bus
  */
  bool IsOnBus() const;
  /**
  * @brief get the destination of a passenger
  * @return a int to specify bus destination
  */
  int GetDestination() const;
  /**
  * @brief print out detailed info
  * @param[in] out output stream
  * @return void
  */
  void Report(std::ostream&) const;

 private:
  /**
  * @brief private members of Passenger
  */
  /**
  * @brief init a std::string name_ to save the name of passenger
  */
  std::string name_;
  /**
  * @brief init a destination stop id
  */
  int destination_stop_id_;
  /**
  * @brief init a wait time at a certain stop
  */
  int wait_at_stop_;
  /**
  * @brief init a time on bus
  */
  int time_on_bus_;
  /**
  * @brief init a passenger ID
  */
  int id_;
  /**
  * @brief to save the number of passenger objects
  */
  static int count_;  // global count, used to set ID for new instances
};
#endif  // SRC_PASSENGER_H_
