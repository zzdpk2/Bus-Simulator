/**
 * @file util.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#ifndef SRC_UTIL_H_
#define SRC_UTIL_H_

/*******************************************************************************
  * Includes
******************************************************************************/
#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <string>

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
* @brief This class is for Util
*
*/
class Util {
 public:
  /**
  * @brief public members of Bus
  */
  /**
  * @brief the preocess output function
  *
  * @param[in] output_stream a string stream
  *
  * @return a vector of string
  */
  static std::vector<std::string>
    processOutput(std::ostringstream& output_stream);
  /**
  * @brief the preocess output function
  *
  * @param[in] strToSplit target string
  * @param[in] delimeter string delimeter
  *
  * @return a vector of string
  */
  static std::vector<std::string>
    split(std::string strToSplit, char delimeter);
};
#endif  // SRC_UTIL_H_
