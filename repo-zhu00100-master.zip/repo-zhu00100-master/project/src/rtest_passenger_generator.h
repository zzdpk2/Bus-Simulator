/**
 * @file rtest_passenger_generator.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */

#ifndef SRC_RTEST_PASSENGER_GENERATOR_H_
#define SRC_RTEST_PASSENGER_GENERATOR_H_

#include <list>
#include <random>
#include <ctime>

#include "src/passenger_generator.h"
#include "src/stop.h"


class Stop;  // forward declaration

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
 * @brief This class is for Regression test for passenger generator
 *
 */
class RtestPassengerGenerator : public PassengerGenerator {
 public:
  /**
  * @brief public members of RtestPassengerGenerator
  */
  /**
  * @brief construcor for RtestPassengerGenerator class.
  *
  * @param[in] probs the list of probs
  * @param[in] stops the list of stops
  *
  * @return no return value
  */
  RtestPassengerGenerator(std::list<double>, std::list<Stop *>);
  /**
  * @brief generate passengers
  *
  * @return a int to show the number of passengers 
  */
  int GeneratePassengers() override;

 private:
  /**
  * @brief private members of RtestPassengerGenerator
  */
  /**
  * @brief save the random number to define the bus type to create
  */
  static std:: minstd_rand0 my_rand;
};

#endif  // SRC_RTEST_PASSENGER_GENERATOR_H_
