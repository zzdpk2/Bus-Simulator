/**
 * @file r1_local_simulator.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#ifndef SRC_R1_LOCAL_SIMULATOR_H_
#define SRC_R1_LOCAL_SIMULATOR_H_

/*******************************************************************************
  * Includes
******************************************************************************/
#include <vector>
#include <string>
#include "src/simulator.h"

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
 * @brief This class is for rLocalSimulatorNew
 *
 */
class rLocalSimulatorNew : public Simulator {
 public:
  /**
  * @brief public members of rLocalSimulatorNew
  */
  /**
  * @brief start simlating
  *
  * @return a bool to show if it is started.
  */
  bool Start() override;
  /**
  * @brief update simlating
  *
  * @return a bool to show if it is updated.
  */
  bool Update() override;

 private:
  /**
  * @brief private members of rLocalSimulatorNew
  */
  /**
  * @brief the bus counters
  */
  std::vector<int> bus_counters_;
  /**
  * @brief all of the bus starting time
  */
  std::vector<int> bus_start_timings_;
  /**
  * @brief all the time of bus since the last bus
  * is generated
  */
  std::vector<int> time_since_last_bus_generation_;
  /**
  * @brief the elapsed simulation time
  */
  int simulation_time_elapsed_;
};

#endif  // SRC_R1_LOCAL_SIMULATOR_H_
