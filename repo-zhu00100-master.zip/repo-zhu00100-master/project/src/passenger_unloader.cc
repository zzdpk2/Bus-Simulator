/**
 * @file passenger_unloader.cc
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
/*******************************************************************************
  * Includes
******************************************************************************/
#include "src/passenger_unloader.h"

/*******************************************************************************
 * Member Functions
 ******************************************************************************/
// Unload passengers
int PassengerUnloader::UnloadPassengers(std::list<Passenger *> passengers,
  Stop * current_stop) {
  // TODO(wendt): may need to do end-of-life here
  // instead of in Passenger or Simulator
  int passengers_unloaded = 0;
  std::ostringstream ss;
  std::vector<std::string> contents;
  FileWriterManager fwm;
  FileWriter fw = fwm.getInstance();
  for (std::list<Passenger *>::iterator it = passengers.begin();
    it != passengers.end(); it++) {
    (*it)-> Report(ss);
    if ((*it)->GetDestination() == current_stop->GetId()) {
      // could be used to inform scheduler of end-of-life?
      // This could be a destructor issue as well.
      // *it->FinalUpdate();
      it = passengers.erase(it);
      // getting seg faults, probably due to reference deleted objects
      // here
      it--;
      passengers_unloaded++;
    }
  }
  contents = Util::processOutput(ss);
  fw.Write("PassData.csv", contents);
  return passengers_unloaded;
}
