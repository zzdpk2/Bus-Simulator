/**
 * @file bus.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#ifndef SRC_BUS_H_
#define SRC_BUS_H_

/*******************************************************************************
  * Includes
******************************************************************************/
#include <iostream>
#include <list>
#include <string>
#include <sstream>

#include "src/data_structs.h"

#include "src/passenger.h"
#include "src/passenger_loader.h"
#include "src/passenger_unloader.h"
#include "src/route.h"
#include "src/stop.h"
#include "src/IObservable.h"
#include "src/IBus.h"

class PassengerUnloader;
class PassengerLoader;
class Route;
class Stop;

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
 * @brief This class is for Bus
 *
 */
// class Bus : public IObservable {
class Bus: public IBus {
 public:
  /**
  * @brief public members of Bus
  */
  /**
  * @brief construcor for Bus class.
  *
  * @param[in] name the bus name
  * @param[in] out departure route
  * @param[in] in incomming route
  * @param[in] capacity bus capacity(default value is 60)
  * @param[in] speed bus speed(default value is -1)
  *
  * @return no return value
  */
  Bus(std::string name, Route * out, Route * in, int capacity = 60,
    double speed = 1);
  /**
  * @brief judge the trip is complete
  *
  * @return a boolean value to show whether
  *   the bus is successfully created
  */
  bool IsTripComplete();
  /**
  * @brief judge the passenger is loaded
  *
  * @param[in] new_passenger refers to the Passenger Object
  *
  * @return a boolean value to show whether
  *   the trip is completed
  */
  bool LoadPassenger(Passenger *);  // returning revenue delta
  /**
  * @brief judge the bus is moving
  *
  * @return a boolean value to show whether
  *   the bus is moved
  */
  bool Move();
  /**
  * @brief judge the bus has updated its location
  *
  * @return void
  */
  void Update();
  /**
  * @brief print out the detailed info of current bus
  *
  * @param[in] out an output stream
  *
  * @return void
  */
  virtual void Report(std::ostream&);
  // Vis Getters
  /**
  * @brief Update bus data
  *
  * @return void
  */
  void UpdateBusData();
  /**
  * @brief Fetch bus data
  *
  * @return the updated BusData object
  */
  BusData GetBusData() const;
  /**
  * @brief Get bus name
  *
  * @return a std::string to show a bus name
  */
  std::string GetName() const { return name_; }
  /**
  * @brief Get next stop
  *
  * @return a Stop* to show a stop
  */
  Stop * GetNextStop() const { return next_stop_; }
  /**
  * @brief Get number of passengers on current bus
  *
  * @return a size_t to specify the number of passengers on a bus
  */
  size_t GetNumPassengers() const { return passengers_.size(); }
  /**
  * @brief Get the capacity of current bus
  *
  * @return a int variable to see the bus capacity
  */
  int GetCapacity() const { return passenger_max_capacity_; }

  int modifyColor();

 protected:
  /**
  * @brief private members of Bus
  */
  /**
  * @brief revenue delta for UnloadPassengers
  */
  int UnloadPassengers();  // returning revenue delta
  // bool Refuel();

  /**
  * @brief init a PassengerUnloader to unload passengers
  */
  PassengerUnloader * unloader_;
  /**
  * @brief init a PassengerLoader to load passengers
  */
  PassengerLoader * loader_;
  /**
  * @brief init a std::list<Passenger *> to hold passengers on bus
  */
  std::list<Passenger *> passengers_;
  /**
  * @brief tag max capacity of passengers
  */
  int passenger_max_capacity_;
  // double revenue_; // revenue collected from passengers, doesn't include
                      // passengers who pay on deboard
  // double fuel_;   // may not be necessary for our simulation
  // double max_fuel_;
  /**
  * @brief tag bus name
  */
  std::string name_;
  /**
  * @brief tag bus speed
  */
  double speed_;  // could also be called "distance travelled in one time step"
  /**
  * @brief specify the out route
  */
  Route * outgoing_route_;
  /**
  * @brief specify the in route
  */
  Route * incoming_route_;
  /**
  * @brief specify the distance to incomming stop
  */
  double distance_remaining_ = 0;
  // when negative?, unload/load procedure occurs
  // AND next stop set
  /**
  * @brief specify the next stop
  */
  Stop * next_stop_;
  // bool trip_complete_;  // [DERIVED data] when BOTH routes are at end, trip
  // is complete
  // Vis data for bus
  /**
  * @brief save the bus travel data
  */
  BusData bus_data_;
  /**
  * @brief save the total number of passenger
  */
  int total_passenger = 0;
  /**
  * @brief save the color
  */
};
#endif  // SRC_BUS_H_
