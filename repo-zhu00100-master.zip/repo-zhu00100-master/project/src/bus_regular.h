/**
 * @file bus_regular.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#ifndef SRC_BUS_REGULAR_H_
#define SRC_BUS_REGULAR_H_

/*******************************************************************************
 * Includes
 ******************************************************************************/
#include <iostream>
#include <list>
#include <string>

#include "src/bus.h"

class PassengerUnloader;
class PassengerLoader;
class Route;
class Stop;

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
 * @brief The main class for the generation of LargeBus.
 *
 * Calls to \ref RegularBus function to get a new instance of a LargeBus.
 *  This is a static call, not requiring an instance to invoke the method.
 */
class RegularBus : public Bus{
 public:
   /**
    * @brief Generation of a regular bus with name, route in, route out, speed.
    *
    * This constrcutor function will be used for simulation purposes.
    *
    * @param[in] bus_name bus name
    * @param[in] out_route out route
    * @param[in] in_route incoming route
    * @param[in] speed bus speed
    *
    * @return a new instance of RegularBus
    */
  RegularBus(std::string bus_name,
    Route * out_route, Route * in_route, double speed = 1)
    : Bus(bus_name, out_route, in_route, 60, speed) {}
  /**
   * @brief print out the information of the bus
   *
   * @param[in] out output stream to print the info
   *
   * @return void.
   */
    void Report(std::ostream&) override;
};
#endif  // SRC_BUS_REGULAR_H_
