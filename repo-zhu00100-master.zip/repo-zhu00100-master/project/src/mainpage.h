/**
 * @file mainpage.h
 *
 * @copyright 2019 Boss, All rights reserved.
 */
#ifndef SRC_MAINPAGE_H_
#define SRC_MAINPAGE_H_
/*! \mainpage PROJECT: VISUAL TRANSIT SYSTEM SIMULATOR
 *
 * \section Introduction Introduction
 * The Visual Transit System Simulator is a project in the University of Minnesota
 *
 * Program Design and Development class(CSCI3081W). The purpose of this simulation
 *
 * is to digitally mock the busses routes in Minneapolis. This project mainly
 *
 * involves four classes: Bus class, Route class, Stop class and Passenger class.
 *
 * \section Obtainment Obtainment
 * 1. Download the zip from https://github.umn.edu/umn-csci-3081-s20/repo-zhu00100
 * 2. Use git command 'git clone https://github.umn.edu/umn-csci-3081-s20/repo-zhu00100'
 *    with access
 *
 * \section Compiling Compiling
 * 1. cd into 3081_s20/repo-zhu00100/project/src
 * 2. type 'make' then enter
 * 3. cd into 3081_s20/repo-zhu00100/project
 * \section Running Running
 * 1. type ./build/bin/vis_sim [port_number] (please specify the port number)
 * 2. turn on a browser and type in ./build/bin/vis_sim [port_number]
 *    (same as the previous port number)
 * 3. In the web page, click start button to start simulation
 * 4. Click pause button to pause the movement
 * 5. Clcik resume button to resume movement
 * 6. You can check the realtime info on terminal
 *
 * \section Discussion1 Discussion1
 *
 * Alternate Implementation:
 * 1. Turn the Bus class into an abstract class by adding 'virtual' keyword
      to all fucntions inside Bus class
 * 2. Override all functions in sub-classes
 * 3. Put the customized functions into the BusFactory class
 *
 * Pros:
 *
 *   By this pattern, the cohension of the project is improved. The project is
 *
 * decoupled. If the software in future needs more update version, it is flexible
 *
 * to add more customized members such as functions and member vars. Every time
 *
 * people want to add new type, you do not need to edit the whole structure of class.
 *
 * Cons:
 *
 *   The cons of implementation is quite obvious as well. If the developer wants
 *
 * to build a Bus classwith certain self-defined parameters, the process will be failed.
 *
 * The Bus class doesn not support being instiantiated forever.
 *
 * \section Discussion2 Discussion2
 *
 * Current Implementation:
 *
 * 1. Add the 'int type' parameter.
 *
 * 2. Create another class Called BusFactory
 *
 * 3. Create the three sub-classes for Bus.
 *
 * 4. Create a member function to generate the random number
 *
 *    and the result will be recorded.
 *
 * 5. Directly generate the Bus classes according to new sub-classes.
 *
 * Pros:
 *
 *   Comparing to the original version, the less encapsulated version is much
 *
 * clearer and more direct because developer can define the type of classes in
 *
 * Generate function. Developers do not need to edit mutiple classes to update
 *
 * new features which makes the whole project more flexible and dynamic.
 *
 * Cons:
 *
 *   If the program is designed by this pattern by creating new sub classes,
 *
 * the structure of this program will be more organized. If in future, the project
 *
 * is getting sophisticated, the new programmer may get clearer about understanding
 *
 * the code to update the program. Also, they program is decoupled and in a better
 *
 * cohension which is is beneficial for future development.
 *
 *
 * \section Desiging Desiging and Implementing the Observer Pattern
 *
 * Designing:
 *
 *   (1) Backend: Obeserver pattern is the pattern to notify the system about any changes
 *
 * on data. In order to create that structure, I do some operations on both backend and
 *
 * frontend. In backend, a class for observer is required to manipulate (clear, update
 *
 * register) data from Bus class. A notify function inside the observer can connect to
 *
 * the frontend to adjust some logics in the backend.
 *
 *   (2) Frontend: Frontend part is to show the data changes to the users including
 *
 * prompt web site printing based on the communication from backend. To keep updateing
 *
 * the data, the listeners should be created.
 *
 * Implementing:
 *
 * (1) Backend:
 *
 * 1. Create an abstract class called IObserver and write a virtual
 *
 *    function called Notify to interact with bus data
 *
 * 2. Create another class in src called IObservable to implement
 *
 *    observer to manipulate data in several concrete operations
 *
 *    such as RegisterObserves, ClearObservers, and NotifyObervers.
 *
 *    RegisterObservers is to add a new oberserver. ClearObservers is
 *
 *    to clear all the attached observers. NotifyObservers is to
 *
 *    notify the frontend to print new data.
 *
 * 3. Build the association between Bus class and IObservable class
 *
 *    by inheritance. Revise the Update function inside Bus class by
 *
 *    inserting NotifyObserver functions into it. Also, update the output
 *
 *     tp terminal. Make sure all the header files are appropriately included.
 *
 * (2) Frontend:
 *
 * 1. Modify JS files to fit the new output.
 *
 * 2. Add new code for adding listeners, clearing listeners,
 *
 *    and notifying the objects.
 *
 * 3. Encapsulate those functions into the UI of simulator and call those functions
 *
 *   in the simulator at the same time.
 *
 * \section Decoration Decoration Pattern
 *
 * (1) option1(I adopt):
 *
 *  Created an IBus interface extended from class IObservable.
 *
 *  There are two classes are extedned from IBus. One is BusDecorator which is to
 *
 *  decorate bus's color as a decorator. The functions for determing intensity and
 *
 *  bus color will be nested in this class. The other class is the original Bus class as
 *
 *  the target to be decorated. This option has a better performance on cohension because
 *
 *  the structure is relatively tight. The code with this design will be clean. The pro of
 *
 *  this style is that the project will be easy to implement which means the workload will
 *
 *  be less. The con is that due to the tight coding structure, the project is hard to be
 *
 *  edited and expanded.
 *

 * (2) option2: Created an IBus interface extended from class IObservable.
 *
 *  There are two classes are extedned from IBus. One is BusDecorator which is to
 *
 *  decorate bus's color as a decorator. The BusDecorater will come out two classes:
 *
 *  BusIntensityDecorator and BusColorDecorator. The functions to determine the bus intensity
 *
 *  will be nested in BusIntensityDecorator. The functions to determine the bus color
 *
 *  will be nested in BusColorDecorator.The other class is the original Bus class as
 *
 *  the target to be decorated. This option has a better performance on coulping because
 *
 *  the structure is not tight. There are more independent functional classes.The pro of
 *
 *  this style is that the project will be easy to expand and edit which means the project
 *
 *  is easier for further development.The con is that due to the complex coding structure,
 *
 *  the project is hard to be implemented in a short time.
 *
 */
#endif  // SRC_MAINPAGE_H_
