/**
 * @file IObserver.h
 *
 * @copyright 2020 3081 Staff, All rights reserved.
 */

#ifndef SRC_IOBSERVER_H_
#define SRC_IOBSERVER_H_

/*******************************************************************************
  * Includes
******************************************************************************/
#include "src/data_structs.h"

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
 * @brief This class is for IObserver with template
 */
template <typename T>
class IObserver{
 public:
   /**
   * @brief public members of IObserver
   */
     /**
   * @brief notify the bus data (virtual)
   *
   * @param[in] info the info needs to be notified
   * @return void
   */
  virtual void Notify(T info) = 0;
};
#endif  // SRC_IOBSERVER_H_
