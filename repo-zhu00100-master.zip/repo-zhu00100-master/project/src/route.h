/**
 * @file route.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#ifndef SRC_ROUTE_H_
#define SRC_ROUTE_H_

/*******************************************************************************
  * Includes
******************************************************************************/

#include <list>
#include <iostream>
#include <string>

#include "src/data_structs.h"

#include "src/passenger_generator.h"
#include "src/stop.h"

class PassengerGenerator;

/*******************************************************************************
* Class Definitions
******************************************************************************/
/**
* @brief This class is for Route
*/
class Route {
 public:
  /**
  * @brief public members of Route
  */
  /**
  * @brief construcor for Route class.
  *
  * @param[in] name route name
  * @param[in] stops array of stops
  * @param[in] distances array of distances
  * @param[in] num_stops number of stops in a route
  * @param[in] generator passenger generator
  * @return no return value
  */
  Route(std::string name, Stop ** stops, double * distances, int num_stops,
    PassengerGenerator *);
  /**
  * @brief This function is to clone a new route
  *
  * @return a new instance of Route
  */
  Route * Clone();
  /**
  * @brief This function is to update a route
  *
  * @return void
  */
  void Update();
  /**
  * @brief This function is to print route info
  * @param[in] out: output stream
  * @return void
  */
  void Report(std::ostream&);
  /**
  * @brief This function is to judge whether reach to the end of a route
  *
  * @return a bool to show whether the trip is at the end
  */
  bool IsAtEnd() const;
  /**
  * @brief This function is to get previous stop
  *
  * @return a new Stop* instance to show the previous stop
  */
  Stop *  PrevStop();  // Returns stop before destination stop
  /**
  * @brief This function is to move to the next stop
  *
  * @return void
  */
  void ToNextStop();   // Change destination_stop_ to next stop
  /**
  * @brief This function is to get the destination stop
  *
  * @return a new instance of Stop* to show the destination stop
  */
  Stop * GetDestinationStop() const;    // Get pointer to next stop
  /**
  * @brief This function is to get the total route distance
  *
  * @return a double to show the destination distance
  */
  double GetTotalRouteDistance() const;
  /**
  * @brief This function is to get the distance to the next stop
  *
  * @return a double to show the distance to the next stop
  */
  double GetNextStopDistance() const;

  // Vis Getters
  /**
  * @brief This function is to get the route name
  *
  * @return a std::string to show the route name
  */
  std::string GetName() const { return name_; }
  /**
  * @brief This function is to get the list of stops
  *curr_stop
  * @return a std::list<Stop *> to show the list of stops
  */
  std::list<Stop *> GetStops() const { return stops_; }
  /**
  * @brief This function is to update route data
  *
  * @return void
  */  
  void UpdateRouteData();
  /**
  * @brief This function is to get the route data
  *
  * @return a updated set of RouteData
  */
  RouteData GetRouteData() const;

 private:
  /**
  * @brief private members of Route
  */
  /**
  * @brief This function is to generate new passengers
  *
  * @return int
  */
  int GenerateNewPassengers();      // generates passengers on its route
  /**
  * @brief Create a passenger generator
  */
  PassengerGenerator * generator_;
  /**
  * @brief Create a list of stops
  */
  std::list<Stop *> stops_;
  /**
  * @brief Create a list of distances
  */
  std::list<double> distances_between_;  // length = num_stops_ - 1
  /**
  * @brief route name
  */
  std::string name_;
  /**
  * @brief Record numbers of stops
  */
  int num_stops_;
  /**
  * @brief Record destination stop index
  */
  int destination_stop_index_;  // always starts at zero, no init needed
  /**
  * @brief Specify the destination stop
  */
  Stop * destination_stop_;
  // double trip_time_; // derived data - total distance travelled on route
  /**
  * @brief Record route data
  */
  RouteData route_data_;
};
#endif  // SRC_ROUTE_H_
