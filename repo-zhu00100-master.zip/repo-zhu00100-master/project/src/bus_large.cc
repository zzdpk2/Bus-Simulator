/**
 * @file bus_large.cc
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
/*******************************************************************************
  * Includes
 ******************************************************************************/
#include "src/bus_large.h"

/*******************************************************************************
 * Member Functions
 ******************************************************************************/
// print detailed info
void LargeBus::Report(std::ostream& out) {
  out << "Name," << name_ << ",";
  out << "Type: Large Bus" << ",";
  out << "Speed," << speed_ << ",";
  out << "Distance,to,next,stop," << distance_remaining_ << ",";
  out << "Passengers," << passengers_.size() << std::endl;
  // for (std::list<Passenger *>::iterator it = passengers_.begin();
  //                                       it != passengers_.end(); it++) {
  //   (*it)->Report(out);
  // }
}
