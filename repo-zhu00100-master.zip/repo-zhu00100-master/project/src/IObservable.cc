/**
 * @file IObservable.h
 *
 * @copyright 2020 Boss, All rights reserved.
 */
#include "src/IObservable.h"
/**
* @brief register observers
*
* @param[in] observer an oberserver needs to be registered
*
* @return void
*/

void IObservable::RegisterObserver(IObserver<BusData*>* observer) {
  bus_observer_.push_back(observer);
}

void IObservable::RegisterObserver(IObserver<StopData*>* observer) {
  stop_observer_.push_back(observer);
}

/**
* @brief clear observers
*
* @return void
*/
void IObservable::ClearObservers() {
  bus_observer_.clear();
  stop_observer_.clear();
}

/**
* @brief notify observers
*
* @param[in] info an bus data needs to be observed
*
* @return void
*/
// Notify observers
void IObservable::NotifyObservers(BusData* info) {
  // Iterate it
  for (unsigned int i = 0; i < bus_observer_.size(); i++) {
    bus_observer_.at(i)->Notify(info);
  }
}
/**
* @brief notify observers
*
* @param[in] info an bus data needs to be observed
*
* @return void
*/
void IObservable::NotifyObservers(StopData* info) {
  // Iterate it
  for (unsigned int i = 0; i < stop_observer_.size(); i++) {
    stop_observer_.at(i)->Notify(info);
  }
}

