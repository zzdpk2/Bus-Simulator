/**
 * @file IObservable.h
 *
 * @copyright 2020 Boss, All rights reserved.
 */
#ifndef SRC_IOBSERVABLE_H_
#define SRC_IOBSERVABLE_H_

/*******************************************************************************
  * Includes
******************************************************************************/
#include <iostream>
#include <vector>

#include "src/IObserver.h"
#include "src/data_structs.h"

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
 * @brief This class is for IObservable
 *
 */
class IObservable {
 public:
    // void RegisterObserver(IObserver<BusData*>* observer);
    /**
    * @brief public members of IObservable
    */
    /**
    * @brief register observers
    *
    * @param[in] observer an oberserver needs to be registered
    *
    * @return void
    */
    void RegisterObserver(IObserver<BusData*>* observer);
    /**
    * @brief register observers
    *
    * @param[in] observer an oberserver needs to be registered
    *
    * @return void
    */
    void RegisterObserver(IObserver<StopData*>* observer);
    /**
    * @brief clear observers
    *
    * @return void
    */
    void ClearObservers();
    /**
    * @brief notify observers
    *
    * @param[in] info an bus data needs to be observed
    *
    * @return void
    */
    // void NotifyObservers(T info);
    void NotifyObservers(BusData* info);
    /**
    * @brief notify observers
    *
    * @param[in] info an bus data needs to be observed
    *
    * @return void
    */
    void NotifyObservers(StopData* info);

 private:
    /**
    * @brief public members of IObservable
    */
    /**
    * @brief an array of observers
    */
    std::vector<IObserver<BusData*>*> bus_observer_;
    std::vector<IObserver<StopData*>*> stop_observer_;
};
#endif  // SRC_IOBSERVABLE_H_
