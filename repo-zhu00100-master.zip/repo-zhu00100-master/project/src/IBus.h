/**
 * @file IBus.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#ifndef SRC_IBUS_H_
#define SRC_IBUS_H_

/*******************************************************************************
  * Includes
******************************************************************************/
#include "src/IObservable.h"

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
* @brief This class is for IBus
*
*/
class IBus : public IObservable {
 public:
  /**
  * @brief public members of IBus
  */
  /**
  * @brief modify color
  *
  * @return an int to show status
  */
  virtual int modifyColor() = 0;
};
#endif  // SRC_IBUS_H_
