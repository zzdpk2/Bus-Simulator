/**
 * @file stop.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#ifndef SRC_STOP_H_
#define SRC_STOP_H_

/*******************************************************************************
  * Includes
******************************************************************************/
#include <list>
#include <iostream>

#include "src/bus.h"
#include "src/passenger.h"
#include "src/data_structs.h"
#include "src/IObservable.h"

class Bus;
/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
 * @brief This class is for Stop
 *
 */
class Stop : public IObservable {
 public:
  /**
  * @brief public members of stop
  */
  /**
  * @brief construcor for Stop class.
  *
  * @param[in] id stop id
  * @param[in] longitude stop longitude
  * @param[in] latitude stop latitude
  * @return no return value
  */
  explicit Stop(int, double = 44.973723, double = -93.235365);
  /**
  * @brief This function is for loading passengers.
  *
  * @param[in] bus: Bus object
  * @return a int to show the loaded passengers
  */
  int LoadPassengers(Bus *);  // Removing passengers from stop
  /**
  * @brief This function is for adding passengers.
  *
  * @param[in] pass a Passenger object
  * @return a int to represent the added passengers
  */
  // and onto a bus
  int AddPassengers(Passenger *);  // Adding passengers
  // to the stop (from the generator)
  /**
  * @brief This function is for updating stop info.
  *
  * @return void
  */
  void Update();
  /**
  * @brief This function is for getting stop ID.
  *
  * @return a int to show stop ID
  */
  int GetId() const;
  /**
  * @brief This function is for printing the stop info
  * @param[in] out output stream
  * @return void
  */
  void Report(std::ostream&) const;
  // Vis Getters
  /**
  * @brief This function is to get longitude
  *
  * @return a double to get longitude
  */
  double GetLongitude() const { return longitude_; }
  /**
  * @brief This function is to get latitude
  *
  * @return a double to get latitude
  */
  double GetLatitude() const { return latitude_; }
  /**
  * @brief This function is to get number of present passengers
  *
  * @return a size_t to get present number of passengers
  */
  size_t GetNumPassengersPresent() { return passengers_.size(); }

 private:
  /**
  * @brief private members of stop
  */
  /**
  * @brief ID of the route
  */
  int id_;
  /**
  * @brief Create the list of passengers
  */
  std::list<Passenger *> passengers_;  // considered array, vector, queue, list
  /**
  * @brief longitude of the stop
  */
  double longitude_;
  /**
  * @brief latitude of the stop
  */
  double latitude_;
  // Are we using long/lat coords?
  // derived information - not needed depending on passengers_
  // data structure implementation?
  // int passengers_present_;
  StopData stop_data_;
};
#endif  // SRC_STOP_H_
