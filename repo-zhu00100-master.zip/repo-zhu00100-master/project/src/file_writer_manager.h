/**
 * @file file_writer_manager.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#ifndef SRC_FILE_WRITER_MANAGER_H_
#define SRC_FILE_WRITER_MANAGER_H_

/*******************************************************************************
  * Includes
******************************************************************************/
#include <iostream>
#include <fstream>
#include "src/file_writer.h"

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
* @brief This class is for FileWriterManager
*
*/
class FileWriterManager {
 public:
  /**
  * @brief to get instance of file writer
  *
  * @return a FileWriter object
  */
  static FileWriter getInstance();
 private:
  static FileWriter file_writer;
};
#endif  // SRC_FILE_WRITER_MANAGER_H_
