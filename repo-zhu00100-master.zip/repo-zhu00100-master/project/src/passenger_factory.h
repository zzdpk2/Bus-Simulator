/**
 * @file passenger_factory.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#ifndef SRC_PASSENGER_FACTORY_H_
#define SRC_PASSENGER_FACTORY_H_

/*******************************************************************************
  * Includes
******************************************************************************/
#include <string>

#include "src/passenger.h"

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
 * @brief This class is for PassengerFactory
 *
 * Calls to \ref Generate function to get a new instance of a bus.
 * This is a static call, not requiring an instance to invoke the method.
 */
class PassengerFactory {
 public:
  /**
  * @brief public members of PassengerFactory
  */
  /**
  * @brief Generation of passengers
  * 
  * @param[in] curr_stop id of current stop
  * @param[in] last_stop id of last stop
  * 
  * @return a Passenger instance
  */
  static Passenger * Generate(int, int);
 private:
  /**
  * @brief private members of PassengerFactory
  */
  /**
  * @brief Generation of a bus name
  * 
  * @return a std::string
  */
  static std::string NameGeneration();
};
#endif  // SRC_PASSENGER_FACTORY_H_
