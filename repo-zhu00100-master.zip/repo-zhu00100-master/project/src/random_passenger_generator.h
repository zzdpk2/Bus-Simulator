/**
 * @file random_passenger_generator.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */

#ifndef SRC_RANDOM_PASSENGER_GENERATOR_H_
#define SRC_RANDOM_PASSENGER_GENERATOR_H_

/*******************************************************************************
  * Includes
******************************************************************************/

#include <list>
#include <random>
#include <ctime>

#include "src/passenger_generator.h"
#include "src/stop.h"

class Stop;  // forward declaration

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
 * @brief This class is for RandomPassengerGenerator
 *
 */
class RandomPassengerGenerator : public PassengerGenerator{
 public:
  /**
  * @brief public members of Bus
  */
  /**
  * @brief construcor for Bus class.
  *
  * @param[in] probs list of probablities
  * @param[in] stops list of stops
  * @return no return value
  */
  RandomPassengerGenerator(std::list<double>, std::list<Stop *>);
  /**
  * @brief override the function to generate passengers
  *
  * @return a int to show the result of passenger generation
  */
  int GeneratePassengers() override;

 private:
  /**
  * @brief private members of Bus
  */
  /**
  * @brief save the int seed for generating random numbers
  */
  static std:: minstd_rand0 my_rand;
};

#endif  // SRC_RANDOM_PASSENGER_GENERATOR_H_
