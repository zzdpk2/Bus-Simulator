/**
 * @file util.cc
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#include "src/util.h"

std::vector<std::string> Util::processOutput(std::ostringstream&
  output_stream) {
  std::string tempString = output_stream.str();
  std::vector<std::string> contents;
  contents = split(tempString, ',');
  return contents;
}

std::vector<std::string> Util::split(std::string strToSplit,
  char delimeter) {
  std::stringstream ss(strToSplit);
  std::string item;
  std::vector<std::string> splittedStrings;
  while (std::getline(ss, item, delimeter)) {
    splittedStrings.push_back(item);
    splittedStrings.push_back(" ");
  }
  return splittedStrings;
}
