/**
 * @file decorator.cc
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#include "src/decorator.h"

Decorator::Decorator(IBus* ibus) {
  bus = ibus;
}

int Decorator::modifyColor() {
  return bus->modifyColor();
}
