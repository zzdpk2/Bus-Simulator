/**
 * @file bus_small.cc
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
/*******************************************************************************
   * Includes
 ******************************************************************************/
#include "src/bus_small.h"

/*******************************************************************************
 * Member Functions
 ******************************************************************************/
// print detailed info
void SmallBus::Report(std::ostream& out)  {
  out << "Name," << name_ << ",";
  out << "Type: Small Bus" << ",";
  out << "Speed," << speed_ << ",";
  out << "Distance,to,next,stop," << distance_remaining_ << ",";
  out << "Passengers," << passengers_.size() << std::endl;
  // for (std::list<Passenger *>::iterator it = passengers_.begin();
  //                                       it != passengers_.end(); it++) {
  //   (*it)->Report(out);
  // }
}
