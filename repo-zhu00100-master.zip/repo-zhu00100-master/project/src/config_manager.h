/**
 * @file config_manager.h
 *
 * @copyright 2019 3081 Staff, All rights reserved.
 */
#ifndef SRC_CONFIG_MANAGER_H_
#define SRC_CONFIG_MANAGER_H_

/*******************************************************************************
  * Includes
******************************************************************************/

#include <vector>
#include <string>


class Route;

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
 * @brief This class is for generating ConfigManager
 */

class ConfigManager{
 public:
    /**
    * @brief public members of ConfigManager
    */
    /**
    * @brief construcor for ConfigManager class.
    *
    * @return no return value
    */
    ConfigManager();
    /**
    * @brief deconstrucor for ConfigManager class.
    *
    * @return no return value
    */
    ~ConfigManager();
    /**
    * @brief This is the ReadConfig function
    * 
    * @param[in] filename specify the file name
    *
    * @return void
    */
    void ReadConfig(const std::string filename);
    /**
    * @brief This is the function to get route
    * 
    * @return vector<Route *>
    */
    std::vector<Route *> GetRoutes() const { return routes; }

 private:
    /**
    * @brief private members of Config Manager
    */
    /**
    * @brief vector to save routes
    */
    std::vector<Route *> routes;
};

#endif  // SRC_CONFIG_MANAGER_H_
